
$( document ).ready(function()
{
    var SELECTEDVERTICLE=$.cookie('SELECTEDVERTICLE')
    SHOWTEAM(SELECTEDVERTICLE)
    /*
$('#Teamlist').append("<option value='" + 'IPS' + "'>")
$('#Teamlist').append("<option value='" + 'QED' + "'>")
$('#Teamlist').append("<option value='" + 'POWERWRAP'+ "'>")
$('#Teamlist').append("<option value='" + 'PMS'+ "'>")
*/
if(SELECTEDVERTICLE!='AA_COMPLIANCE')
{
    $('.BOX_3').hide()
}
else{
    var Add_element=
    "<div class='Manager_SELCTION'> <table class='View_Selection'> <thead><tr><th>Status Update</th><th>Current User</th></tr></thead> <tbody class='Tbody_z'><tr><td><button class='Button_click0'>Click</button></td><td><button class='Button_click1'>Click</button></td></tr></tbody> </table></br></br> <button class='btn btn-primary' onclick=window.location.href='/download_excel_format_for_AA_compliance'>Download Excel Format</button><form id='uplaod_AA_Compliance_Team' enctype='multipart/form-data'><input type='file' name='uplaod_AA_Compliance_Team'accept='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'><input class='btn btn-success' type='submit' value='Upload'></form></div>"
    $('.BOX_3').append(Add_element)
}
try{
    var TEAMname=$.cookie('SELECTEDTEAM')      
    $('.SELECT_team').val(TEAMname)
    
}
catch{
    pass
}


var Tdate=moment().format('YYYY-MM-DD')
var html=

"<div class='BOX_5'><h2>Data as of "+ Tdate +"</h2><button class='refreshx'>Refresh</button><table class='liveDATA'><thead><tr><th>DATE</th><th>TEAM</th><th>Employee ID</th><th>Employee Name</th><th>Activity</th><th>Process</th><th>Started time</th><th>Status</th></tr></thead><tbody class='LIVEdb'></tbody></table></div>"
if(SELECTEDVERTICLE!='AA_COMPLIANCE'){
    $('.BOX_1').append(html);
}


var XTEAMX=$('.SELECT_team').val()
$.ajax
({
    url : '/api/GETUSERLIVEDATA',
    data:{'XTEAMX':XTEAMX},
    success:function(data)
    {
        var len = data['LIVE_DATE'].length;
        var html = '';

        for (var i = 0; i< len; i++)
        {   
               
             var html = '<tr>'+                                          
                '<td class="APPLIED_DATE">' +data['LIVE_DATE'][i]+ '</td>' +  
                '<td class="APPLIED_TEAM">' +data['LIVE_TEAM'][i]+ '</td>' +  
                '<td class="APPLIED_EMPIDS">' +data['LIVE_EMPID'][i]+ '</td>' +     
                '<td class="APPLIED_EMPNAME">' +data['LIVE_EMPNAME'][i]+ '</td>' +   
                '<td class="APPLIED_ACTIVITY">' +data['LIVE_ACTIVITY'][i]+ '</td>' +  
                '<td class="APPLIED_PROCESS">' +data['LIVE_ACTNAME'][i]+ '</td>' +  
                '<td class="APPLIED_STARTTIME">' +data['LIVE_STARTTIME'][i]+ '</td>' + 
                '<td class="DYNAMIC_STATUS">' +'WIP'+ '</td>' +   
                '</tr>';                                   
                $('.LIVEdb').append(html);
        }
    }})
})


$(document).on('click','.Button_click1',function()
{
    
    $('.SHOW_STATUSdiv').remove();$('.SHOW_STATUSdiv table').remove()
    var SELECTEDVERTICLE=$.cookie('SELECTEDVERTICLE')
    var Tdate=moment().format('YYYY-MM-DD')
    var html=

    "<div class='BOX_5'><h2>Data as of "+ Tdate +"</h2><button class='refreshx'>Refresh</button><table class='liveDATA'><thead><tr><th>DATE</th><th>TEAM</th><th>Employee ID</th><th>Employee Name</th><th>Activity</th><th>Process</th><th>Started time</th><th>Status</th></tr></thead><tbody class='LIVEdb'></tbody></table></div>"
    
    $('.BOX_1').append(html);
    


    var XTEAMX=$('.SELECT_team').val()
    $.ajax
    ({
        url : '/api/GETUSERLIVEDATA',
        data:{'XTEAMX':XTEAMX},
        success:function(data)
        {
            var len = data['LIVE_DATE'].length;
            var html = '';

            for (var i = 0; i< len; i++)
            {   
                
                var html = '<tr>'+                                          
                    '<td class="APPLIED_DATE">' +data['LIVE_DATE'][i]+ '</td>' +  
                    '<td class="APPLIED_TEAM">' +data['LIVE_TEAM'][i]+ '</td>' +  
                    '<td class="APPLIED_EMPIDS">' +data['LIVE_EMPID'][i]+ '</td>' +     
                    '<td class="APPLIED_EMPNAME">' +data['LIVE_EMPNAME'][i]+ '</td>' +   
                    '<td class="APPLIED_ACTIVITY">' +data['LIVE_ACTIVITY'][i]+ '</td>' +  
                    '<td class="APPLIED_PROCESS">' +data['LIVE_ACTNAME'][i]+ '</td>' +  
                    '<td class="APPLIED_STARTTIME">' +data['LIVE_STARTTIME'][i]+ '</td>' + 
                    '<td class="DYNAMIC_STATUS">' +'WIP'+ '</td>' +   
                    '</tr>';                                   
                    $('.LIVEdb').append(html);
            }
        }})
})
$(document).on('click','.Button_click0',function()
{
    $('.BOX_5').remove();$('.SHOW_STATUSdiv').remove();$('.SHOW_STATUSdiv table').remove()
    new_div="<div class='SHOW_STATUSdiv'><table><thead><tr><th>Vertical</th><th>Team</th><th>Entity name</th><th>Current_Status</th><th>Status</th></tr> </thead> <tbody class='LIVE_ENTITY'></tbody></table></div>"
    $('.BOX_3').append(new_div)

    TEAM=$('.SELECT_team').val()
    SHOW_WORKFLOW(TEAM)
})


function SHOW_WORKFLOW(TEAM)
{

            $.ajax
            ({
                url : '/api/SHOW_WORKFLOW',
                data:{'XTEAMX':TEAM},
                success:function(data)
                {
                    console.log(data['N_ENTITY'])
                    var len = data['N_ENTITY'].length;
                    var html = '';
            
                    console.log('Append')
                    
                    for (var i = 0; i< len; i++)
                    {   
                           
                         var html = '<tr>'+                                          
                            '<td class="LIVE_VERTICAL">' +data['VERTICAL'][i]+ '</td>' +  
                            '<td class="LIVE_TEAM">' +data['TEAMNAME'][i]+ '</td>' +  
                            '<td class="LIVE_ENTITYx">' +data['N_ENTITY'][i]+ '</td>' +     
                            '<td class="LIVE_STATUS">' +data['X_STATUS'][i]+ '</td>' + 
                            '<td class="LIVE_BUTTON"><Button class="UPDATE_ENTITYSTATUS">Complete</Button></td>' + 
                            '</tr>';                                   
                            $('.LIVE_ENTITY').append(html);  
                    } 
                                     
                }})

}

function SHOWTEAM(verticle)
{

    $('.INP_1').val(null);$('#dataXlist').empty()
	$.getJSON("/static/JSONFOLDER/TEAMvsVERTICLE.json", function(data)
			{
                console.log('in')
                var SELECTEDVERTICLE=verticle
				BREAKX_LAYERS=data[SELECTEDVERTICLE]
                console.log(BREAKX_LAYERS)				
				REMARK_LAYERS=data.LIST_OF_REMARKS                   
				var l=0;var m=0
				for (var i=0;i<BREAKX_LAYERS.length;i++)
					{				                        
						var BRKXLayer=BREAKX_LAYERS[i].LIST
                        console.log(BRKXLayer)
						let BRKXlist = document.getElementById('Teamlist');
						var option = document.createElement('option');
						option.value = BRKXLayer;
						BRKXlist.appendChild(option);  						

					}
			})


} 


$(document).on('change','.SELECT_team',function()
{
    $.cookie('SELECTEDTEAM',$('.SELECT_team').val(),{expires:1})

})    
$(document).on('click','.UPDATE_ENTITYSTATUS',function()
{
//    alert($(this).closest('tr').find('td:nth-child(4)').text())
    var Vertical_frm_List=$(this).closest('tr').find('td:nth-child(1)').text()
    var Team_frm_List=$(this).closest('tr').find('td:nth-child(2)').text()
    var EntityName_frm_List=$(this).closest('tr').find('td:nth-child(3)').text()    
    alert(Vertical_frm_List + Team_frm_List + EntityName_frm_List)
    $.ajax
    ({
        url : '/api/DELETE_WORKFLOW_FRMLIST',
        data:{'VERTICAL':Vertical_frm_List,'TEAMNAME':Team_frm_List,'ENITYNAME':EntityName_frm_List},
        success:function(data)
        {
                $('.LIVE_ENTITY').remove()
                TEAM=$('.SELECT_team').val()
                SHOW_WORKFLOW(TEAM)
        }})    
})
$(document).on('click','.FINDTEAM',function()
{
            
            var inx = $('.DYN_TBL1').index(this);
            $('.BOX_4').eq(inx).remove();
            $('.SHOWCASE_0').eq(inx).remove();

            var Tdate=moment().format('YYYY-MM-DD')
            var TEAMname=$.cookie('SELECTEDTEAM')  
            var html=
            "<div class='BOX_4'><h2>Team Name - "+ TEAMname +"</h2><table class='REPORToptionS'><thead><th>FROM</th><th>TO</th></thead><tbody><tr><td><input class='FROMDATE' type='date' value="+Tdate+"></input></td><td><input class='TODATE' type='date' value="+Tdate+"></input></td><td><button class='DateRef'>GO</button></td></tr></tbody></table></div>"+
            "<div class='SHOWCASE_0'><table class='DYN_TBODY_A'><thead class='DYN_THEAD_A'><th>Total Users</th><th>TOTAL hours</th></thead><tbody class='DYN_TBODY_A'><tr><td><input class='CountofUser' ></input></td><td><input class='TOTALhrs' ></input></td><td><button class='OverallPDF'>PDF</button></td><td><button class='OverallCSV'>Excel</button></td></tr></tbody></table></div>"
            

            $('.DYN_TBODY1').append(html); 




            var STARTDate=$('.FROMDATE').val()
            var ENDDate=$('.TODATE').val()    
            var XTEAMX=$('.SELECT_team').val()

            if(XTEAMX.length==0){
                alert('Need Data')
                return false
            }

            $.ajax
            ({
                url : '/api/ADMINgraph',
                data:{'XTEAMX':XTEAMX,'SDATE':STARTDate,'EDATE':ENDDate},
                success:function(data)
                {

                    const obj =data['XIDS']

                    const arr = Object.entries(obj)
                    .reduce((r, [k, v]) => {
                    console.log(v)
                      if(!r[v]) r[v] = [];
                      r[v].push(v);
                      return r;
                    }, {})
                    
                    console.log(Object.values(arr))
                    console.log(arr.length)
                    
                    try{
                        console.log(data['XIDS'])


                        var TOTAL_Array = [];var NONPROCESS_Array = [];var PROCESS_Array = [];
                        lenx=data['PREPPROCOUNT'].length
                        for(var x=0;x<lenx;x++){
                            TOTAL_Array.push(data['PREPPROCOUNT'][x][1])                                                
                            TOTAL_Array.push(data['PREPPROCOUNT'][x][1])                                                
                            TOTAL_Array.push(data['PREPPROCOUNT'][x][1])                                                                            
                        }
                        console.log(TOTAL_Array)

        
                        const anyPRO =    TOTAL_Array
                        const PROsum = anyPRO.reduce((acc, time) => acc.add(moment.duration(time)), moment.duration());                
                        console.log([Math.floor(PROsum.asHours()), PROsum.minutes(), PROsum.seconds()].join(':'));
                        TOTAL_PROCESS_TIME=[Math.floor(PROsum.asHours()), PROsum.minutes(), PROsum.seconds()].join(':')
            
                        $('.TOTALhrs').val(TOTAL_PROCESS_TIME)
        
                        console.log('Enter')
                    }catch{
                        console.log('Nill Data')
                    }
        
                }})  
                

            
            $.ajax
            ({
                url : '/api/GETUSERLIST',
                data:{'XTEAMX':XTEAMX},
                success:function(data)
                {
                    console.log(data['xUSERLISTx'].length)
                    len=data['xUSERLISTx'].length
                    if(TOTAL_PROCESS_TIME=='0:0:0'){
                        $('.CountofUser').val(null)
                    }else{
                        $('.CountofUser').val(len)
                    }
                    
        
                    Timeval=data['xHOURSx']
                    const any = data['xHOURSx']
        
                    const sum = any.reduce((acc, time) => acc.add(moment.duration(time)), moment.duration());
                    
                    console.log([Math.floor(sum.asHours()), sum.minutes()].join(':'));
        
                    var TotalHrs=[Math.floor(sum.asHours()), sum.minutes()].join(':')
                    /*
                    for(var i=0;i<len;i++)
                    {
                        xval=data['xUSERLISTx'][i]
                        data['xUSERLISTx'].length
                        var html=
                        "<tr><td><input class='CX' type='checkbox'></input></td><td><input class='xUSER' value="+xval +"></input></td><td><button class='xVIEW'>view</button></td></tr>"
                        $('.DYN_TBODY0').append(html);     
                    }                    
                    */
                    
                }})                
            

        })

//    })
//})


$(document).on('click','.DateRef',function()
{
    console.log('testing')
    var STARTDate=$('.FROMDATE').val()
    var ENDDate=$('.TODATE').val()    
    var XTEAMX=$('.SELECT_team').val()
    $.ajax
    ({
        url : '/api/ADMINgraph',
        data:{'XTEAMX':XTEAMX,'SDATE':STARTDate,'EDATE':ENDDate},
        success:function(data)
        {
            try{

                //console.log(data['XIDS'])
                //var groupedData = data['XIDS'].length
                //console.log(groupedData)
                
                console.log(data['XIDS'])
                var TOTAL_Array = [];var NONPROCESS_Array = [];var PROCESS_Array = [];
                lenx=data['PREPPROCOUNT'].length
                for(var x=0;x<lenx;x++){
                    TOTAL_Array.push(data['PREPPROCOUNT'][x][1])                                                
                    TOTAL_Array.push(data['PREPPROCOUNT'][x][1])                                                
                    TOTAL_Array.push(data['PREPPROCOUNT'][x][1])                                                                            
                }
                console.log(TOTAL_Array)

                const anyPRO =    TOTAL_Array
                const PROsum = anyPRO.reduce((acc, time) => acc.add(moment.duration(time)), moment.duration());                
                console.log([Math.floor(PROsum.asHours()), PROsum.minutes(), PROsum.seconds()].join(':'));
                TOTAL_PROCESS_TIME=[Math.floor(PROsum.asHours()), PROsum.minutes(), PROsum.seconds()].join(':')
    
                $('.TOTALhrs').val(TOTAL_PROCESS_TIME)

                console.log('Enter')
            }catch{
                console.log('Nill Data')
            }

        }})
        $.ajax
        ({
            url : '/api/GETUSERLIST',
            data:{'XTEAMX':XTEAMX},
            success:function(data)
            {
                console.log(data['xUSERLISTx'].length)
                len=data['xUSERLISTx'].length
                if(TOTAL_PROCESS_TIME=='0:0:0'){
                    $('.CountofUser').val(null)
                }else{
                    $('.CountofUser').val(len)
                }
                
    
                Timeval=data['xHOURSx']
                const any = data['xHOURSx']
    
                const sum = any.reduce((acc, time) => acc.add(moment.duration(time)), moment.duration());
                
                console.log([Math.floor(sum.asHours()), sum.minutes()].join(':'));
    
                var TotalHrs=[Math.floor(sum.asHours()), sum.minutes()].join(':')
                /*
                for(var i=0;i<len;i++)
                {
                    xval=data['xUSERLISTx'][i]
                    data['xUSERLISTx'].length
                    var html=
                    "<tr><td><input class='CX' type='checkbox'></input></td><td><input class='xUSER' value="+xval +"></input></td><td><button class='xVIEW'>view</button></td></tr>"
                    $('.DYN_TBODY0').append(html);     
                }                    
                */
                
            }})                      
})




$(document).on('click','.OverallPDF',function()
{

    var url=document.URL;
    var urls=url.substr(url.lastIndexOf('?')+1,url.length);
    const param=url.split('/')                    
    var S_DATE=$('.FROMDATE').val();    
    var E_DATE=$('.TODATE').val();  
    var USERX=param[4]
    //var DATE_x=new Date();    
    var TEAM_x=$('.SELECT_team').val();  
    console.log(TEAM_x)         

      
    
    $.ajax
    ({                        
        url :'/api/DownlUserX' ,                      
        type: 'GET',         
        xhrFields:{
            responseType: 'blob'
        },
        data:{'XTEAMX':TEAM_x,'SDATE':S_DATE,'EDATE':E_DATE,'XUSERX':USERX,'XTEAMX':TEAM_x,'USERMODE':'ADMIN'},
        success: function(data) 
        {         
            var blob = data;
            console.log(data)
            var link=document.createElement('a');
            link.href=window.URL.createObjectURL(blob);
            link.download= new Date() + ".pdf";
            link.click();            
        }
    })
})

$(document).on('click','.OverallCSV',function(){    
    var url=document.URL;
    var urls=url.substr(url.lastIndexOf('?')+1,url.length);
    const param=url.split('/')                    
    var S_DATE=$('.FROMDATE').val();    
    var E_DATE=$('.TODATE').val();  
    var USERX=param[4]
    //var DATE_x=new Date();    
    var TEAM_x=$('.SELECT_team').val();  
    console.log(TEAM_x)              
    
    $.ajax
    ({                        
        url :'/api/AdminDOWNLOADTEAM' ,                      
        type: 'GET',         
        xhrFields:{
            responseType: 'blob'
        },
        data:{'XTEAMX':TEAM_x,'SDATE':S_DATE,'EDATE':E_DATE,'XUSERX':USERX,'USERMODE':'ADMIN'},
        success: function(data) 
        {         

            console.log(data)
            var blob = data;
            var downloadUrl = URL.createObjectURL(blob);
            var a = document.createElement("a");
            a.href = downloadUrl;
            a.style.display = 'none';
            a.download = "TEAM : "+TEAM_x+" Data from -"+S_DATE+" to - "+E_DATE +".xls";
            document.body.appendChild(a);
            a.click();
            
            
        }
    })
})

//.xVIEW
$(document).on('click','.refreshx',function()
{
    $('.liveDATA').remove()
    /*
    var Xvalue=$(this).find('.xUSER').val()    
    console.log(Xvalue)
    if(Xvalue==''){
        alert('Null value not Accepted')
        return false
    }
    var len =1
    var html = '';
    
    
    for (var i = 0; i< len; i++)
    {   }})
    */
    var Tdate=moment().format('YYYY-MM-DD')
    var html=
    
    "<div class='BOX_5'><h2>Data as of "+ Tdate +"</h2><button class='refreshx'>Refresh</button><table class='liveDATA'><thead><tr><th>Date</th><th>Team</th><th>Employee id</th><th>Employee Name</th><th>Activity</th><th>Process</th><th>Started time</th><th>Status</th></tr></thead><tbody class='LIVEdb'></tbody></table></div>"
    
    $('.BOX_1').append(html);
    var TEAMname=$.cookie('SELECTEDTEAM')     
    var XTEAMX=TEAMname
    console.log(XTEAMX)
    $.ajax
    ({
        url : '/api/GETUSERLIVEDATA',
        data:{'XTEAMX':XTEAMX},
        success:function(data)
        {
            var len = data['LIVE_DATE'].length;
            var html = '';
    
            for (var i = 0; i< len; i++)
            {   
                   
                 var html = '<tr>'+                                          
                    '<td class="APPLIED_DATE">' +data['LIVE_DATE'][i]+ '</td>' +  
                    '<td class="APPLIED_TEAM">' +data['LIVE_TEAM'][i]+ '</td>' +  
                    '<td class="APPLIED_EMPIDS">' +data['LIVE_EMPID'][i]+ '</td>' +     
                    '<td class="APPLIED_EMPNAME">' +data['LIVE_EMPNAME'][i]+ '</td>' +     
                    '<td class="APPLIED_ACTIVITY">' +data['LIVE_ACTIVITY'][i]+ '</td>' +  
                    '<td class="APPLIED_PROCESS">' +data['LIVE_ACTNAME'][i]+ '</td>' +  
                    '<td class="APPLIED_STARTTIME">' +data['LIVE_STARTTIME'][i]+ '</td>' + 
                    '<td class="DYNAMIC_STATUS">' +'WIP'+ '</td>' +   
                    '</tr>';                                   
                    $('.LIVEdb').append(html);
    
            }
        }})
    
})

$(document).on('click','.LOGOUT',function()
{
            $.removeCookie('SELECTEDTEAM')   
            $.removeCookie('PREV_SELECTED_TEAM', { path: '/' })
            $.removeCookie('SELECTEDVERTICLE', { path: '/' })   
            $.removeCookie('STATUS',{ path: '/' })
            $.removeCookie('session',{ path: '/' })  
	    var url=document.URL;
	    var urls=url.substr(url.lastIndexOf('?')+1,url.length);
	    const param=url.split('/')   
            $.ajax({
                url:'/api/logout',
                success:function(data){
                    window.location.reload()

		    console.log(param[0]+param[1]+param[2])
		    redirect_to=param[0]+'//'+param[1]+param[2]
		    $(location).prop('href',redirect_to)
		
                }
            })



})

$(function() {
    $('#multiFiles').on('change', function () {
        
/*
    document.getElementById("SEARCHME").disabled = true;
    document.getElementById("DOWNLOADFORMATLINK").disabled = true;
    document.getElementById("UPDATEBTN").disabled = true;
    document.getElementById("CLEARLBTN").disabled = true;    
    document.getElementById("multiFiles").disabled = true;
*/
    var form_data = new FormData();
    var ins = document.getElementById('multiFiles').files.length;
    var TEAM='BONGIORNO' 
    var vertical=$.cookie('SELECTEDVERTICLE')
    if(ins == 0) {
//        $('#msg').html('<span style="color:red">Select at least one file</span>');
        alert('Select At Least One File')
        return;
    }

    for (var x = 0; x < ins; x++) {
        form_data.append("files[]", document.getElementById('multiFiles').files[x]);
    }
    
    $.ajax({
        url: '/upload', // point to server-side URL
        dataType: 'json', // what to expect back from server
        cache: false,
        contentType: false,
        processData: false,
        data: form_data,
        type: 'post',        
        success: function (data) { // display success response            
            {                
                console.log('Upload')
                $.ajax({
                    url:'/api/READXLSX',
                    data:{'TEAMNAME':TEAM,'VERTICALNAME':vertical},
                    success:function(data){
                        alert(data['DETAILS'])
                        window.location.reload()
                        alert('Upload success')    
                    }
                })
            }}})})})

//For upload AA_compliance excel - 08/05/2023
$(document).on('submit','#uplaod_AA_Compliance_Team', function(event) {
	event.preventDefault();
	var forData = new FormData(this);
	$.ajax({
		url: '/uplaod_AA_Compliance_Team',
		type: 'POST',
		data: forData,
		cache:false,
		contentType:false,
		processData: false,
		success: function(response) {
		    alert('File Uploaded Successfully');
            window.location.reload();
		},
		error:function(xhr, status,error){
		    alert('Error');
            window.location.reload();
		}
	});
});
//end upload AA_compliance excel          