var Updateicon="<img src = /static/styles/imagex/upgrade.png alt = 'UpdateB image' width = '25' height = '25'>"
var Deleteicon="<img src = /static/styles/imagex/delete.png alt = 'DeleteB image' width = '25' height = '25'>"
var NOTIFICATION="<img src = /static/styles/imagex/bulb0.png alt = 'DeleteB image' width = '25' height = '25'>"
var WARNING="<img src = /static/styles/imagex/warning.png alt = 'DeleteB image' width = '25' height = '25'>"

$(document).ready(function(){

    if(typeof $.cookie('TEAM')==='undefined'){
	console.log('create new data')
        $.getJSON("/static/JSONFOLDER/LOT.json", function(data)
        {
            
            
            BREAKX_LAYERS=data['TEAM']
            console.log(BREAKX_LAYERS)				
            REMARK_LAYERS=data.LIST_OF_REMARKS   

            var l=0;var m=0
            for (var i=0;i<BREAKX_LAYERS.length;i++)
                {				                        
                    var BRKXLayer=BREAKX_LAYERS[i].V_name
                    console.log(BRKXLayer)
                    let BRKXlist = document.getElementById('Verticallist');
                    var option = document.createElement('option');
                    option.value = BRKXLayer;
                    BRKXlist.appendChild(option);  						

                }
        })
    }else{
/*
        var len =1
        var html = '';
    
        for (var i = 0; i< len; i++)
        {   
                       
            let colName='BRKLAYERxDYN'+[i]
            let inpName='BRKINP'+[i]+'xDYN'
            let REMARKName='REMARKLAYERxDYN'+[i]
            let REMARKinpName='REMARKINP'+[i]+'xDYN'            
            var html=

            "<td class="+colName+"><input type='text' class="+inpName+"></input><button class="+"APPENDBREAK"+">SAVE</button></td>"+
            "<td class="+REMARKName+"><input type='text' class="+REMARKinpName+"></input><button class="+"APPENDREMARK"+">SAVE</button></td>"
             $('.DYN_TBODY02').first().after(html);
        }
*/
        var TEAMNAME= $.cookie('TEAM')+'.json'
        
        $.getJSON('/static/JSONFOLDER/'+TEAMNAME,function(data){

            len=data[0]['configure']['NOCol']
            console.log(len)
            for (var i = 0; i< len; i++)
                {   
                    
                    let colName='LAYERxDYN'+[i]
                    let inpName='INP'+[i]+'xDYN'
                    var PLACEHOLDER
                    switch(i){
                        case 0:
                            if(i==0){
                                    PLACEHOLDER='ACTIVITY LAYER'                                
                                    }                                
                        case 1:
                            if(i==1){
                                PLACEHOLDER='SUB LAYER'                            
                                    }
                        case 2:
                            if(i==2){                                
                                PLACEHOLDER='MAIN LAYER'
                                    }
                    }
                    console.log(i)
                    var html=
                    
                    //"<td class="+colName+"><input type='text' class="+inpName+"></input><button class="+"APPEND"+">+ SUT</button><td class="+colName+"><input type='text' class="+inpName+"></input><button class="+"APPEND"+">SAVE</button></td></td>"
                    "<td class="+colName+"><input type='text' class="+inpName+" placeholder="+PLACEHOLDER+"></input><button class="+"APPEND"+">SAVE</button><button class="+"APPENDSUT"+">+ SUT</button></td>"
                    
                    $('.DYN_TBODY01').first().after(html);
                }
                //DYN_TBODY01
        })
    }
})

$(document).on('change','.SELECT_Vertical',function()
{

    $('.SELECT_team').val(null);$('#Teamlist').empty()
	$.getJSON("/static/JSONFOLDER/TEAMvsVERTICLE.json", function(data)
			{
                console.log('in')
                var SELECTEDVERTICLE=$('.SELECT_Vertical').val()
				BREAKX_LAYERS=data[SELECTEDVERTICLE]
//                console.log(BREAKX_LAYERS)				
				REMARK_LAYERS=data.LIST_OF_REMARKS   
                $.cookie('SELECTEDVERTICLE',SELECTEDVERTICLE,{expires:10})
                console.log(SELECTEDVERTICLE)
				var l=0;var m=0
				for (var i=0;i<BREAKX_LAYERS.length;i++)
					{				                        
						var BRKXLayer=BREAKX_LAYERS[i].LIST
                        console.log(BRKXLayer)
						let BRKXlist = document.getElementById('Teamlist');
						var option = document.createElement('option');
						option.value = BRKXLayer;
						BRKXlist.appendChild(option);  						

					}
			})


})


$(document).on('click','.APPEND',function()
{
    
        

    var ele_pos=$(this).closest('td').index()
    
    if(ele_pos==1){
        var Mainlayer=$('.INP2xDYN').val()
        $.cookie("MAINLAYER",Mainlayer,{expires:1})
        alert(ele_pos)
    }else if(ele_pos==2){
        var SUBlayer=$('.INP1xDYN').val()
        $.cookie("SUBLAYER",SUBlayer,{expires:1})
        alert(ele_pos)
    }

        
    var TEAMNAME= $.cookie('TEAM')+'.json'
    console.log(ele_pos)
    
    var Xvalue=$(this).closest('td').find('input').val()
    var LAYERX=$(this).closest('td').find('input').val()
        
    console.log(ele_pos,Xvalue,TEAMNAME)
    switch(ele_pos)
    {
        case 1:
            REQ_DATA={'SLOT':'0','LAYER':Xvalue,'TEAMNAME':TEAMNAME}
            alert("1")
            break
        case 2:
            var M=$.cookie("MAINLAYER")
            REQ_DATA={'SLOT':'1','LAYER':Xvalue,'TEAMNAME':TEAMNAME,'NAMELAYER':M}
            alert(M)
            console.log('X')
            break
        case 3:
            var L=$.cookie("SUBLAYER")
            var MLAYER=$.cookie("MAINLAYER")
            REQ_DATA={'SLOT':'2','LAYER':Xvalue,'TEAMNAME':TEAMNAME,'NAMELAYER':L,'MXL':MLAYER}
            alert(L)
            alert(MLAYER)
            alert("3")
            break            
        case 4:
            REQ_DATA={'SLOT':'3','LAYER':Xvalue,'TEAMNAME':TEAMNAME,'NAMELAYER':LAYERX}
            break            
        case 5:
            REQ_DATA={'SLOT':'4','LAYER':Xvalue,'TEAMNAME':TEAMNAME,'NAMELAYER':LAYERX}
            break            
        case 6:
            REQ_DATA={'SLOT':'5','LAYER':Xvalue,'TEAMNAME':TEAMNAME,'NAMELAYER':LAYERX}
            break            
        case 7:
            REQ_DATA={'SLOT':'6','LAYER':Xvalue,'TEAMNAME':TEAMNAME,'NAMELAYER':LAYERX}
            break            
        case 8:
            REQ_DATA={'SLOT':'7','LAYER':Xvalue,'TEAMNAME':TEAMNAME,'NAMELAYER':LAYERX}
            break            
    }
    console.log(REQ_DATA)
    $.ajax
    ({
        url : '/api/CONFIGxTEAMDATA',
        data:REQ_DATA,
        success:function(data)
        {
            window.location.reload()
        }
    })
})

$(document).on('click','.APPENDSUT',function()
{
    
    var Xvalue=$(this).closest('td').find('input').val()    
    if(Xvalue==''){
        alert('Null value not Accepted')
        return false
    }
    var len =1
    var html = '';
    
    
    for (var i = 0; i< len; i++)
    {   
                   
        let colName='DYNMODAL'+[i]
        let inpName='MODALINP'+[i]+'xDYN'
        let REMARKName='REMARKLAYERxDYN'+[i]
        let REMARKinpName='REMARKINP'+[i]+'xDYN'            
        let INPVal=Xvalue
        var html=
        "<div class='MODAL'>"+
            "<div class='contains'>"+        
                "<input type='text' class="+colName+" value="+INPVal+"></input>"+
                "<input type='time' step=1 class="+inpName+" value='00:01:00'></input>"+
                "<button class="+"saveSUT"+">SAVE</button>"
            +"</div>"
        +"</div>"
        //"<td class="+colName+"><input type='text' class="+inpName+"></input></td>"+
        //"<td class="+REMARKName+"><input type='text' class="+REMARKinpName+"></input><button class="+"APPENDSUT"+">SAVE</button></td>"
         $('.BOX3').first().after(html);
    }

})


$(document).on('click','.saveSUT',function()
{
    var ele_pos=$(this).closest('td').index()
    var TEAMNAME= $.cookie('TEAM')+'.json'
    var Xvalue=$(this).closest('td').find('input').val()
    var XSUT=$('.MODALINP0xDYN').val()
    console.log(XSUT)
    
    REQ_DATA={'TEAMNAME':TEAMNAME,'LAYERSUT':XSUT,'LAYERDATA':$('.DYNMODAL0').val()}
    
    $.ajax
    ({
        url : '/api/SUTxTEAMDATA',
        data:REQ_DATA,
        success:function(data)
        {
            window.location.reload()
        }
    })
})

$(document).on('click','.SETaTEAM',function()
{
    var Teamx=$('.TEAMNAME').val()
    $.ajax
    ({
        url : '/api/CREATExTEAM',
        data:{'TEAMNAME':Teamx},
        success:function(data)
        {
            $.cookie('TEAM',data['TEAMNAME'],{expires:10})
        }
    })
})

$(document).on('click','.config',function()
{
    var TeamX=$('.TEAMNAME').val()
    var NOofCol=$('.NOOFCOL').val()
    $.ajax
    ({
        url : '/api/CONFIGxTEAM',
        data:{'TEAMNAME':TeamX,'NOoFcol':NOofCol},
        success:function(data)
        {
            window.location.reload()
        }})

})

$(function() {
    $('#multiFiles').on('change', function () {
        
/*
    document.getElementById("SEARCHME").disabled = true;
    document.getElementById("DOWNLOADFORMATLINK").disabled = true;
    document.getElementById("UPDATEBTN").disabled = true;
    document.getElementById("CLEARLBTN").disabled = true;    
    document.getElementById("multiFiles").disabled = true;
*/
    var form_data = new FormData();
    var ins = document.getElementById('multiFiles').files.length;
    var TEAM=$('.SELECT_team').val()
    var vertical=$('.SELECT_Vertical').val()
    if(ins == 0) {
//        $('#msg').html('<span style="color:red">Select at least one file</span>');
        alert('Select At Least One File')
        return;
    }

    for (var x = 0; x < ins; x++) {
        form_data.append("files[]", document.getElementById('multiFiles').files[x]);
    }

	if(vertical=='M@NI'){
        $.ajax({
            url: '/uploadM', // point to server-side URL
            dataType: 'json', // what to expect back from server
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type: 'post',        
            success: function (data) { // display success response            
                {                
                    console.log('Upload')
                            alert('Upload success')    

                    
                }}})
            return false
            }  
    
    $.ajax({
        url: '/upload', // point to server-side URL
        dataType: 'json', // what to expect back from server
        cache: false,
        contentType: false,
        processData: false,
        data: form_data,
        type: 'post',        
        success: function (data) { // display success response            
            {                
                console.log('Upload')
		console.log(vertical,TEAM)
                $.ajax({
                    url:'/api/READXLSX',
                    data:{'TEAMNAME':TEAM,'VERTICALNAME':vertical},
                    success:function(data){
			alert(data['DETAILS'])
                        window.location.reload()
//$(location).prop('href', 'http://127.0.0.1:5000/')

                    }
                })
            }}})})})

$(document).on('click','.LOGOUT',function()
{
            $.removeCookie('SELECTEDTEAM')   
            $.removeCookie('TEAM')
            $.removeCookie('SELECTEDTEAM',{ path: '/' })   
	    $.removeCookie('TEAM', { path: '/' })


        
            $.ajax({
                url:'/api/logout',
                success:function(data){
                    window.location.reload()
$(location).prop('href', 'http://10.9.55.62:50990/')

                }
            })



})

$(document).on('click','.UPDATE_Details',function()
{
   $('.DYN_TBL5').empty();$('.BOX4 #searchInput').remove()
    TEAMNAME=$('.SELECT_team').val()+'.json'
    var map = {};
    //console.log(TEAMNAME)
    
    var html='<input id="searchInput" placeholder="Search Activity"><br/>'
    $('.BOX4').append(html);
    var html=    
    "<thead><tr><th>Layer 1</th><th>Activity</th><th>Current SUT</th><th>New SUT</th><th>SUT Add</th><th>Layer Remove</th></tr></thead><tbody class='DYN_TBODY05'></tbody>"
    $('.DYN_TBL5').append(html);

    $.getJSON('/static/JSONFOLDER/'+TEAMNAME,function(data)
                {    
                    len=data[2]['SUTinfo']

                    for (var i = 0; i< len.length; i++)
                    {    
                        const object =data[2]['SUTinfo'][i]
                        
                        for (const [key, value] of Object.entries(object)) {
                            Q=key;
                            A=value
                          }
                          
                        var html = '<tr>'+                                    
                        '<td><input placeholder="Select user" class="SUT_DynInp_layer1" list="SUT_DynInp_layer1_list"><datalist id="SUT_DynInp_layer1_list"></datalist></input></td>'
                        +'<td>'+ Q+'</td>'
                        +'<td>'+ A+'</td>'
                        +'<td><input class="SUT_DynInp_current" type="time" step=1 value="00:00:00"></input></td>'
                        +"<td><button class='UpdateNewSUT'><i class='material-icons' >"+ Updateicon +"</i></button></td>"
                        +"<td><button class='RemoveExtSUT'><i class='material-icons' >"+ Deleteicon +"</i></button></td>"
                        +'</tr>'
                        $('.DYN_TBODY05').append(html);

                        
                    }
                    
                }
            ) 
            $.getJSON('/static/JSONFOLDER/'+TEAMNAME,function(data)
            {  
            xlen=data[1]['LAYER'][0]['LAYERx1']
            console.log(xlen)
            
            for (var xi = 0; xi< xlen.length; xi++)
            {
                var BRKXLayer=xlen[xi]['LAYER1']
                console.log(BRKXLayer)
                let BRKXlist = document.getElementById('SUT_DynInp_layer1_list');
                var option = document.createElement('option');
                option.value = BRKXLayer;
                BRKXlist.appendChild(option);  				
                
                if (map[option.value]) {
                    $(option).remove()
                }
                map[option.value] = true;
            }
        })
        $('html, body').animate({scrollTop:100},'00');

})
$(document).on('keyup',"#searchInput",function(){
    
	var rows = $(".DYN_TBODY05").find("tr").hide();
	var data = this.value.split(" ");
	$.each(data, function(i, v) {
		rows.filter(":contains('" + v + "')").show();
	});
    


});

$(document).on('click','.UpdateNewSUT',function()
{

    var TEAM=$('.SELECT_team').val()
    var $row = $(this).closest("tr"),        // Finds the closest row <tr> 
    Col_1 = $row.find(".SUT_DynInp_layer1")
    Col_2 = $row.find("td:nth-child(2)")
    Col_3 = $row.find("td:nth-child(3)")
    Col_4 = $row.find(".SUT_DynInp_current")
    
    
    UserType = Col_1.val();    Activity = Col_2.text();    Pre_SUT = Col_3.text();    New_SUT = Col_4.val()

    console.log(TEAM,UserType,Activity,Pre_SUT,New_SUT)
    $.ajax({
        url:'/api/EDITSUT',
        data:{'TEAMNAME':TEAM,'p_1':UserType,'p_2':Activity,'p_3':Pre_SUT,'p_4':New_SUT},
        success:function(data)
        {
            console.log('Success')
            if(data['ONGOING_PROCESS']=='Update Success'){
                $('.material-iconsC').remove()
                $('.infotextC').remove()
                $('.info').css('display','');     
                var html="<i class='material-iconsC' >"+ NOTIFICATION +"</i><p class='infotextC'>"+data['ONGOING_PROCESS']+"</p>"
                $('.info').append(html);
                $('.info').css('background-color','rgb(0, 255, 98)');
                setTimeout(function() { $('.info'). hide(); }, 5000);
            }else{
                $('.material-iconsD').remove()
                $('.infotextD').remove()
                $('.info').css('display','');     
                var html="<i class='material-iconsD' >"+ WARNING +"</i><p class='infotextC'>"+data['ONGOING_PROCESS']+"</p>"
                $('.info').append(html);
                $('.info').css('background-color','rgb(238, 20, 20) ');
                $('.info').css('color','white');
                setTimeout(function() { $('.info'). hide(); }, 5000);
            }

        }
    
    })

})

$(document).on('click','.REMOVE_Details',function()
{
    var TEAM=$('.SELECT_team').val()
    if(TEAM==''){
        alert('no data')
    }
    $.ajax({
        url:'/api/RemoveJSON',
        data:{'TEAMNAME':TEAM},
        success:function(data)
        {
            NOTIFICATION=data['ONGOING_PROCESS']
            $('.material-iconsC').remove()
            $('.infotextC').remove()
            $('.info').css('display','');     
            var html="<i class='material-iconsC' >"+ NOTIFICATION +"</i><p class='infotextC'>Removed Successfully</p>"
            $('.info').append(html);
            $('.info').css('background-color','rgb(0, 255, 98)');
            setTimeout(function() { $('.info'). hide(); }, 5000);            
        }})    
})

$(document).on('click','.RemoveExtSUT',function()
{
    var TEAM=$('.SELECT_team').val()
    var $row = $(this).closest("tr"),        // Finds the closest row <tr> 
    Col_1 = $row.find(".SUT_DynInp_layer1")
    Col_2 = $row.find("td:nth-child(2)")
    Col_3 = $row.find("td:nth-child(3)")
    Col_4 = $row.find(".SUT_DynInp_current")
    
    
    UserType = Col_1.val();    Activity = Col_2.text();    Pre_SUT = Col_3.text();    New_SUT = Col_4.val()

    console.log(TEAM,UserType,Activity,Pre_SUT,New_SUT)
    $.ajax({
        url:'/api/DELETESUT',
        data:{'TEAMNAME':TEAM,'p_1':UserType,'p_2':Activity,'p_3':Pre_SUT,'p_4':New_SUT},
        success:function(data)
        {
                        if(data['ONGOING_PROCESS']!='Unable to complete Task Try again later'){
                            $('.material-iconsC').remove()
                            $('.infotextC').remove()
                            $('.info').css('display','');     
                            var html="<i class='material-iconsC' >"+ NOTIFICATION +"</i><p class='infotextC'>Removed Successfully</p>"
                            $('.info').append(html);
                            $('.info').css('background-color','rgb(0, 255, 98)');
                            setTimeout(function() { $('.info'). hide(); }, 5000);
                        }else{
                            $('.material-iconsD').remove()
                            $('.infotextD').remove()
                            $('.info').css('display','');     
                            var html="<i class='material-iconsD' >"+ WARNING +"</i><p class='infotextC'>"+data['ONGOING_PROCESS']+"</p>"
                            $('.info').append(html);
                            $('.info').css('background-color','rgb(238, 20, 20) ');
                            $('.info').css('color','white');
                            setTimeout(function() { $('.info'). hide(); }, 5000);
                        }
        }
    
    })

})

//****
$(document).on('click','.LOGINOUTbtn',function()
{
    $('.Report_table').remove();$('.close_report').remove()

    var relm="<table class='Report_table'><thead><tr><th>From</th><th>To</th><th>option</th></tr></thead><tbody><tr><td><input class='Rep_Fromdate' type='Date'></input></td><td><input class='Rep_Todate' type='Date'></input></td><td><button class='report_DOWNLOADX'>Download</button></td></tr></tbody></table>"
    $('.BOXX1').first().after(relm);
    var clem="<button class='close_report'>x</button>"
    $('.Report_table').first().after(clem);
})

$(document).on('click','.close_report',function()
{
    $('.Report_table').remove();$('.close_report').remove()
})



$(document).on('click','.report_DOWNLOADX',function(){    
    var url=document.URL;
    var urls=url.substr(url.lastIndexOf('?')+1,url.length);
    const param=url.split('/')                    
    var S_DATE=$('.Rep_Fromdate').val();    
    var E_DATE=$('.Rep_Todate').val();  
    var USERX=param[4]
    //var DATE_x=new Date();    
    //var TEAM_x=$('.SELECT_team').val();  
      
    
    $.ajax
    ({                        
        url :'/api/loginoutDOWNLOAD' ,                      
        type: 'GET',         
        xhrFields:{
            responseType: 'blob'
        },
        data:{'SDATE':S_DATE,'EDATE':E_DATE},
        success: function(data) 
        {         

            console.log(data)
            var blob = data;
            var downloadUrl = URL.createObjectURL(blob);
            var a = document.createElement("a");
            a.href = downloadUrl;
            a.style.display = 'none';
            a.download =  "Overall Log In Out Data from -"+S_DATE+" to - "+E_DATE +".xls";
            document.body.appendChild(a);
            a.click();
            
            
        }
    })
})

$(document).on('click','.OVERALLREPT',function()
{
    $('.Report_table_O').remove();$('.close_report_O').remove()
    
    var relm="<table class='Report_table_O'><thead><tr><th>From</th><th>To</th><th>Vertical</th><th>option</th></tr></thead><tbody><tr><td><input class='Rep_Fromdate' type='Date'></input></td><td><input class='Rep_Todate' type='Date'></input></td><td><input class='Vertical_Options' list='Vertical_list_O'></input><datalist id='Vertical_list_O'></datalist></td><td><button class='report_DOWNLOADX_O'>Download</button></td></tr></tbody></table>"
    $('.BOXX1').first().after(relm);
    var clem="<button class='close_report_O'>x</button>"
    $('.Report_table_O').first().after(clem);    
    DisplayVertical()
})

function DisplayVertical()
{
    $.getJSON("/static/JSONFOLDER/LOT.json", function(data)
    {
        console.log('in')        
        BREAKX_LAYERS=data['TEAM']	
        REMARK_LAYERS=data.LIST_OF_REMARKS           
        let BRKXlist = document.getElementById('Vertical_list_O'); var option = document.createElement('option');option.value = 'ALL';
        BRKXlist.appendChild(option); 
        for (var i=0;i<BREAKX_LAYERS.length;i++)
            {				                        
                var BRKXLayer=BREAKX_LAYERS[i].V_name
                console.log(BRKXLayer)
                let BRKXlist = document.getElementById('Vertical_list_O');
                var option = document.createElement('option');
                option.value = BRKXLayer;
                BRKXlist.appendChild(option);  						
            }            
    })
}

$(document).on('click','.close_report_O',function()
{
    $('.Report_table_O').remove();$('.close_report_O').remove()
})

$(document).on('click','.report_DOWNLOADX_O',function(){    
    var url=document.URL;
    var urls=url.substr(url.lastIndexOf('?')+1,url.length);
    const param=url.split('/')                    
    var S_DATE=$('.Rep_Fromdate').val();    
    var E_DATE=$('.Rep_Todate').val();  
    var USERX=param[4]
    //var DATE_x=new Date();    
    var TEAM_x=$('.Vertical_Options').val();  
    console.log(TEAM_x)              
    console.log(S_DATE,E_DATE)
    $.ajax
    ({                        
        url :'/api/AdminDOWNLOADTEAM' ,                      
        type: 'GET',         
        xhrFields:{
            responseType: 'blob'
        },
        data:{'XTEAMX':TEAM_x,'SDATE':S_DATE,'EDATE':E_DATE,'XUSERX':USERX,'USERMODE':'MIS'},
        success: function(data) 
        {         

            console.log(data)
            var blob = data;
            var downloadUrl = URL.createObjectURL(blob);
            var a = document.createElement("a");
            a.href = downloadUrl;
            a.style.display = 'none';
            a.download = "TEAM : "+TEAM_x+" Data from -"+S_DATE+" to - "+E_DATE +".xls";
            document.body.appendChild(a);
            a.click();
            
            
        }
    })
})