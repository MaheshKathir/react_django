var url=document.URL;
var urls=url.substr(url.lastIndexOf('?')+1,url.length);
const param=url.split('/')
var ToCONTINUEorNOT=param[4]+localStorage.getItem('UniqSessionID')
var CheckOnGoing=ToCONTINUEorNOT+'Activity'
var PROCESSMODE=ToCONTINUEorNOT+'CPROCESSMODE'
var BREAKSTARTED_AT=ToCONTINUEorNOT+'START_OF_BRK'
var BREAKENDED_AT=ToCONTINUEorNOT+'END_OF_BRK'
var JOB_STARTED_AT=ToCONTINUEorNOT+'WI_START_AT'

var playxIcon="<img src = /static/styles/imagex/play.png alt = 'play image' width = '25' height = '25'>"
var stopxIcon="<img src = /static/styles/imagex/stop.png alt = 'stop image' width = '25' height = '25'>"
var pausexIcon="<img src = /static/styles/imagex/pause.png alt = 'pause image' width = '25' height = '25'>"
var resumeIcon="<img src = /static/styles/imagex/replay.png alt = 'resume image' width = '25' height = '25'>"
var logout="<img src = /static/styles/imagex/logout.png alt = 'logOut image' width = '25' height = '25'>"
var NOTIFICATIONX="<img src = /static/styles/imagex/bulb.png alt = 'DeleteC image' width = '26' height = '26'>"
var NOTIFICATION="<img src = /static/styles/imagex/bulb0.png alt = 'DeleteA image' width = '25' height = '25'>"
var WARNING="<img src = /static/styles/imagex/warning.png alt = 'DeleteB image' width = '30' height = '30'>"
var ADDBTN="<img src = /static/styles/imagex/Add1.png alt = 'AddB image' width = '25' height = '25'>"
var ADDSUCS="<img src = /static/styles/imagex/Tickmark.png alt = 'AddB image' width = '25' height = '25'>"
var ERRINDI="<img src = /static/styles/imagex/error.png alt = 'ErrB image' width = '25' height = '25'>"

SET_COOKIES=["LAYER0","LAYER1","LAYER2","LAYER3","LAYER4","LAYER5","LAYER6","LAYER7","SUTcookie"]
LETSROCK=localStorage.getItem("TYPE_OF_ACTIVITY")	

$(document).ready(function(){
    $('.INP_0').val(param[4])
    if($('.INP_0').val()==''){
        $('.LOGINREGISTER').css('display','')
        $('.DYN_T0').hide()
    }
    

    FILENAMEX=param[4]+'log.json'
    console.log(FILENAMEX)
    console.log('/static/JSONFOLDER/USER_JSON/'+FILENAMEX)
    $.getJSON('/static/JSONFOLDER/USER_JSON/'+FILENAMEX,function(data){
        console.log('in')
        console.log(data[0]['logDetails'][1]['STATUS'])
        var check_STATUS=data[0]['logDetails'][1]['STATUS']
        console.log(check_STATUS)
        //$('.INP_0').val(str(param[4]))
        
        switch(check_STATUS)
        {
            case 'LOGGED_IN':
                //$('.lable_1').hide()
                //$('.ELE_1').hide()
                var VERTICLENAME= $.cookie('SELECTEDVERTICLE')
                var USER_TYPE= $.cookie('MODE')
                if(typeof $.cookie('MODE')==='undefined' || USER_TYPE==''){
                    ROLE_value='Select'
                }else{
                    ROLE_value=USER_TYPE
                }

                if(VERTICLENAME=='AA_COMPLIANCE'){
                    var spanx="<span class='SuperSpan0'><button class='ADDTOLIST_X'>+</button></span>"
                    $('.BOX_1').append(spanx);
                    var X_Table="<table class='TABLE_X'><thead><tr><th>Role</th></tr></thead><tbody class='TABLE_X_TBODY'><tr><td><input class='USERCODE' value="+ ROLE_value +" list='ROLELIST'><datalist id=ROLELIST></input></td></tr></tbody></table>"
                    $('.BOX_1').append(X_Table);
                    $.getJSON("/static/JSONFOLDER/BREAK_AND_REMARKS.json", function(data)
                    {
                        try{
                            n=0
                            USRTYP_LAYERS=data.LIST_OF_USERS
                            for (;n<USRTYP_LAYERS.length;n++)
                            {
                                let USERXLayer=USRTYP_LAYERS[n].TYPE
                                let USERXlist = document.getElementById('ROLELIST');
                                var option = document.createElement('option');
                                option.value = USERXLayer;
                                USERXlist.appendChild(option);  
                                console.log(USERXLayer)    
                            }       
                        }
                        catch{
                            console.log('Not Found')
                        }
                    })
                }
                $('.ELE_2').hide()
                $('.INFOX').hide()                
                $('.INP_0').prop('disabled', true)
                $('.INP_1').prop('disabled', true)
                $('.INP_2').prop('disabled', true)
                $('.INP_1').val(data[0]['logDetails'][3]['SELECTED_TEAM'])
                $('.INP_0').val(data[0]['logDetails'][0]['USERNAME'])
                $('.INP_2').val(data[0]['logDetails'][2]['LOGGED_AT'])
		$('.Footers').css('display','')
                $('.ELE_4').show()
                var TEAM=data[0]['logDetails'][3]['SELECTED_TEAM']
                console.log(TEAM)
                $.cookie('TEAM',data[0]['logDetails'][3]['SELECTED_TEAM'],{expires:1})
                SHOWTABLE();
                SHOWGRAPHICS();
                PUBLISHDATA()
                console.log(data[2].LOGGED_AT)
                myInterval=setInterval(function ()
                {
                    var Today= new Date()
                    var Time=Today.getHours()+':'+Today.getMinutes()+':'+Today.getSeconds()
                    var CurTime=Time

                    let startTime=data[0]['logDetails'][2]['LOGGED_AT']
                    let endTime=CurTime

                    var CalcTime=moment.utc(moment(endTime,"HH:mm:ss").diff(moment(startTime,'HH:mm:ss'))).format('HH:mm:ss')
                    document.title=CalcTime
                    var timeZone = moment.tz.guess();
                    console.log(timeZone)
                    $.cookie('TIMEZONE',timeZone ,{expires:1})

                },1000)
                
                
                var PAGE_STATUS= $.cookie('STATUS')
                console.log(PAGE_STATUS)
                switch(PAGE_STATUS)
                {
                    case"NONPROCESS":
                    $(".BOX_1").css('display','none')
                    $(".DYN_T1").css('display','none')
                    console.log($('.BREAKINFO').length )
                    if ($('.BREAKINFO').length == 0) {
                        var html=                                        
                        "<th>Actual</th><th>SUT</th><th>SELECT A BREAK</th><th>REMARK IF ANY</th>"        
                        $('.DYN_THEAD2').append(html);  
                        if(LETSROCK=='PROCESS')
                        {
                            var html=                                        
                            "<td><span class='BREAKACTUAL'>00:00:00</span></td><td><span class='BREAKSUT'>00:00:00</span></td><td><input class='BREAKINFO' list='BREAKLAYERLIST'><datalist id=BREAKLAYERLIST></input></td><td><input class='REMARKINFO' list='REMARKLAYERLISTx'><datalist id=REMARKLAYERLIST></input></td><td><button class='RESUMEBTN'><i class='material-icons'>"+resumeIcon+"</i></button></td>"
                            $('.DYN_TBODY2').append(html);
                        }else{
                            var html=                                        
                            "<td><span class='BREAKACTUAL'>00:00:00</span></td><td><span class='BREAKSUT'>00:00:00</span></td><td><input class='BREAKINFO' list='BREAKLAYERLIST'><datalist id=BREAKLAYERLIST></input></td><td><input class='REMARKINFO' list='REMARKLAYERLISTx'><datalist id=REMARKLAYERLIST></input></td><td><button class='STOPBREAKBTN'><i class='material-icons'>"+stopxIcon+"</i></button></td>"
                            $('.DYN_TBODY2').append(html);

                        }

                        console.log('Break Clicked')
                        FILL_REMARKANDBRK()
                    }
                    
                    case'IDLE':
                    if(PAGE_STATUS=='IDLE'){
                    for (var i = 0; i< 1; i++)
                    {   
                                
                        var html=
                        "<div class='MODAL'>"+
                            "<div class='contains'>"+                                
                            "<table><thead><th>IDLE TIME</th></thead><tbody><td><span class='IDLEBREAKACTUAL'>00:00:00</span></td><td><input class='REMARKINFO' list='REMARKLAYERLIST'><datalist id=REMARKLAYERLIST></input></td><td><button class='STOPIDLEBREAKBTN'>continue</button></td><td><pre class='info1'>*You have been idle for more than 2 minutes </pre><br><pre class='info2'> please provide the reason below and continue</pre></td></tbody></table>"
                            +"</div>"
                        +"</div>"
                        $('.BOX_0').first().after(html);
                        $('.BOX_0').hide();$('.BOX_1').hide();$('.BOX_2').hide();$('.BOX_3').hide();$('.BOX_4').hide()
                        $('.Footers').css('display','none')
                        
                    }                    
                }       
                    default:                            
                            break
                            
                }                
                try{
                        $.getJSON('/static/JSONFOLDER/USER_JSON/'+FILENAMEX,function(data){            
                            myInterval=setInterval(function ()
                            {
                                var Today= new Date()
                                var timeZone = moment.tz.guess();
//                                var Time=Today.getHours()+':'+Today.getMinutes()+':'+Today.getSeconds()
                                if (timeZone!='Asia/Calcutta'){
                                    $.cookie('TIMEZONE',timeZone ,{expires:1})
                                    var Time=moment().tz("Asia/Calcutta").format('H:mm:ss')
                                }else{
                                    var Time=moment().format('H:mm:ss')
                                }
                                var CurTime=Time
                                switch(PAGE_STATUS){
                                    case "PROCESS":
                                        if ($.cookie('STATUS')=='PROCESS'){                                            
                                            $(".STARTBTN").prop('disabled', true)                                                                                        
                                            AddFrmCookie()
                                            let startTime=data[1]['PROCESS'][1]['STARTED_AT']
                                            console.log(data[1]['PROCESS'][1]['STARTED_AT'])                                
                                            let endTime=CurTime            
                                            var CalcTime=moment.utc(moment(endTime,"H:mm:ss").diff(moment(startTime,'H:mm:ss'))).format('H:mm:ss')
                                            $('#ActualTime').text(CalcTime)                                            
                                        }
                                    case "NONPROCESS":
                                        if ($.cookie('STATUS')=='NONPROCESS'){
                                            
                                            let startTime=data[2]['NONPROCESS'][1]['STARTED_AT']
                                            console.log(data[2]['NONPROCESS'][1]['STARTED_AT'])                                
                                            let endTime=CurTime            
                                            var CalcTime=moment.utc(moment(endTime,"H:mm:ss").diff(moment(startTime,'H:mm:ss'))).format('H:mm:ss')
                                            $('.BREAKACTUAL').text(CalcTime)                                            
                                            $.cookie('TIMESPENTONBREAK', CalcTime,{expires:1})
                                        }
                                    case "IDLE":
                                        if ($.cookie('STATUS')=='IDLE'){
                                            console.log('check01')
                                            let startTime=data[2]['NONPROCESS'][1]['STARTED_AT']
                                            console.log(data[2]['NONPROCESS'][1]['STARTED_AT'])                                
                                            let endTime=CurTime            
                                            var CalcTime=moment.utc(moment(endTime,"H:mm:ss").diff(moment(startTime,'H:mm:ss'))).format('H:mm:ss')
                                            if($('.IDLEBREAKACTUAL').text()!='Invalid date'){
                                                $('.IDLEBREAKACTUAL').text(CalcTime)
                                            }else{
                                                let startTime=data[0]['logDetails'][2]
                                                let endTime=CurTime            
                                                var CalcTime=moment.utc(moment(endTime,"H:mm:ss").diff(moment(startTime,'H:mm:ss'))).format('H:mm:ss') 
						                        $('.IDLEBREAKACTUAL').text(CalcTime) 
                                            }                                                                                         
                                            $.cookie('TIMESPENTONBREAK', CalcTime,{expires:1})
                                        }                                        
                                    case "RESUME":
                                        if ($.cookie('STATUS')=='RESUME'){
                                            $(".BOX_1").css('display','')
                                            $(".DYN_T1").css('display','')
                                            let startTime=data[1]['PROCESS'][1]['STARTED_AT']                                        
                                            let endTime=CurTime            
                                            var CalcTime=moment.utc(moment(endTime,"H:mm:ss").diff(moment(startTime,'H:mm:ss'))).format('H:mm:ss')                                                                                
                                            $(".STARTBTN").prop('disabled', true)    
                                            AddFrmCookie()
                                            console.log('RESUME')
                                            let dayduration=CalcTime
                                            let anotherhour=data[3]['MID_0FF'][1]['STARTED_AT']
                                            console.log(anotherhour)
                                            let RESUMED_TIME=moment(moment(dayduration,'H:mm:ss').diff(moment(anotherhour,'H:mm:ss'))).utc().format('H:mm:ss')
                                            console.log(CalcTime,'-',anotherhour)                                        
                                            console.log(moment(moment(dayduration,'H:mm:ss').diff(moment(anotherhour,'H:mm:ss'))).utc().format('H:mm:ss'))
                                            $('#ActualTime').text(RESUMED_TIME)                                            
                                        }
                                }
                            },1000)
                        })                    
                }
                catch
                {                         
                    console.log('nill cookies')               
                }

                break
            default:
                console.log(param[4])                
                $('.ELE_4').hide()
                $('.lable_2').css({ display : "none" })

        }
    })
})
function FILL_VERTICAL(){
	$.getJSON("/static/JSONFOLDER/LOT.json", function(data)
			{
                VERTICAL_LAYERS=data.TEAM
                var m=0
                for (;m<VERTICAL_LAYERS.length;m++)
                {
                    let VERXLayer=VERTICAL_LAYERS[m].V_name
                    let VERXlist = document.getElementById('dataXlistv');
                    var option = document.createElement('option');
                    option.value = VERXLayer;
                    VERXlist.appendChild(option);  
                    console.log(VERXLayer)                             
                }
            })}
function FILL_STATUS(){
	$.getJSON("/static/JSONFOLDER/BREAK_AND_REMARKS.json", function(data)
			{

                STATUS_LAYERS=data.LIST_OF_STATUS
                var m=0
                for (;m<STATUS_LAYERS.length;m++)
                {
                    let STSXLayer=STATUS_LAYERS[m].STATUS_LAYER
                    let STSXlist = document.getElementById('STATUSLAYERLIST');
                    var option = document.createElement('option');
                    option.value = STSXLayer;
                    STSXlist.appendChild(option);  
                    console.log(STSXLayer)                             
                }
            })
        }
function FILL_REMARKANDBRK(){
	$.getJSON("/static/JSONFOLDER/BREAK_AND_REMARKS.json", function(data)
			{
                console.log('in')
				BREAKX_LAYERS=data.LIST_OF_BREAKS
				REMARK_LAYERS=data.LIST_OF_REMARKS
				var l=0;var m=0
				for (var i=0;i<BREAKX_LAYERS.length;i++)
					{								
						for (;l<REMARK_LAYERS.length;l++)
						{
							let RMRKLayer=REMARK_LAYERS[l].REMARKS
							let RMRKlist = document.getElementById('REMARKLAYERLIST');
							var option = document.createElement('option');
							option.value = RMRKLayer;
							RMRKlist.appendChild(option);  
							console.log(RMRKLayer)
							//console.log(DEALING_TRANSPROCESSERSUB_LAYERS.length)
						}
						var BRKXLayer=BREAKX_LAYERS[i].BREAK_LAYER
						let BRKXlist = document.getElementById('BREAKLAYERLIST');
						var option = document.createElement('option');
						option.value = BRKXLayer;
						BRKXlist.appendChild(option);  						
					}
			})
}
function SHOWTABLE()
{
    var TEAMFILENAME=$.cookie("TEAM") 
    var VERTICLENAME= $.cookie('SELECTEDVERTICLE')
    var map={}
    console.log(TEAMFILENAME)
    $.getJSON('/static/JSONFOLDER/USER_JSON/'+FILENAMEX,function(data){

        if(VERTICLENAME=='AA_COMPLIANCE')
        {
            var html=        
            "<th>Trans.</th><th>SUT</th><th>Actual</th><th>Main Layer</th><th>Sub Layer</th><th>Activity</th><th>Remarks</th>"        
            $('.DYN_THEAD1').append(html);              
            $('.DYN_TBODY1').css('margin-right','-10px')
            $('.DYN_THEAD1').css('margin-right','-25px')

        }else{
        var html=
        
        "<th>Trans.</th><th>SUT</th><th>Actual</th><th>Main Layer</th><th>Sub Layer</th><th>Activity</th><th>Remarks</th>"
        
        $('.DYN_THEAD1').append(html);  
	}

        var html=
        "<td><input class='UNITS' type=number value=1 min='1'></input></td><td><span id='SUTTime'>00:00:00</span></td><td><span id='ActualTime'>00:00:00</span></td>"

        $('.DYN_TBODY1').append(html);  

        var TEAMNAME= $.cookie('TEAM')+'.json'        
        $.getJSON('/static/JSONFOLDER/'+TEAMNAME,function(data){


            len=data[0]['configure']['NOCol']

                      

            for (var i = 0; i<= len; i++)
                {   
                    let xPlacholders=''
                    switch(i){
                    case 0:
                            xPlacholders='Main_Layer'
                            break
                    case 1:
                            xPlacholders='Sub_Layer'
                            break
                    case 2:
                            xPlacholders='Activity_Layer'
                            break                       
                    case 3:
                            xPlacholders='Remarks'
                            break                                                    
                    }

                                                            
                    let colName='LAYERxDYN'+[i]
                    let inpName='INP'+[i]+'xDYN'
                    let LAYERLISTDYN='LAYERLIST'+[i]
                  // adding for incorporating only values limited to the code
                  let myinput = 'myinput'+[i]
                  let myclass = 'myclass'+[i]
                  
                  var html=                                        
                  "<td class="+colName+">" +"<input type='text' class="+inpName+" list="+LAYERLISTDYN+" id="+myinput+" placeholder="+xPlacholders+" ><datalist class="+myclass+" id="+LAYERLISTDYN+"></input>"+'</td>' +                             
                  $('.DYN_TBODY1').append(html);

                }

                var html=
                "<td><button class='STARTBTN'><i class='material-icons' >"+ playxIcon +"</i></button></td><td><button class='SAVEBTN'><i class='material-icons'>"+ stopxIcon +"</i></button></td><td><button class='BREAKBTN'><i class='material-icons'>"+ pausexIcon +"</i></button></td>"
                $('.DYN_TBODY1').append(html);                        
            COlnumber=data[0]['configure']['NOCol']
            x=0
            
            while(x<COlnumber){
                
                xLAYERx='LAYERx'+(x+1)
                yLAYERy=String('LAYER'+(x+1))
                console.log(xLAYERx,yLAYERy)
                XLAYERLIST1=data[1]['LAYER'][x][xLAYERx]
                
                BREAKX_LAYERS=data.LIST_OF_BREAKS
                for (var i=0;i<XLAYERLIST1.length;i++)
                    {
                        if(x==0){
                            if(VERTICLENAME!='AA_COMPLIANCE'){
                                var BRKXLayer=XLAYERLIST1[i].LAYER1
                            }else{
                                var BRKXLayer=XLAYERLIST1[i].FIND    
                            }

                        }else if(x==1){
                            var BRKXLayer=XLAYERLIST1[i].LAYER2
                        }else if(x==2){
                            var BRKXLayer=XLAYERLIST1[i].LAYER3
                        }else if(x==3){
                            var BRKXLayer=XLAYERLIST1[i].LAYER4
                        }else if(x==4){
                            var BRKXLayer=XLAYERLIST1[i].LAYER5
                        }else if(x==5){
                            var BRKXLayer=XLAYERLIST1[i].LAYER6
                        }else if(x==6){
                            var BRKXLayer=XLAYERLIST1[i].LAYER7
                        }                        
                        let BRKXlist = document.getElementById('LAYERLIST'+(x));
                        var option = document.createElement('option');
                        option.value = BRKXLayer;
                        BRKXlist.appendChild(option);                        
                        
                        if (map[option.value]) {
                            $(option).remove()
                        }
                        map[option.value] = true;
                    }                    
                  x++
            }            
        })


    })
    

}

// To validate the option values input box like main layer,sub layer, activity
$(document).on('change','#myinput0', function(){

    var input = document.querySelector('#myinput0');
    var optionFound = false;
    var datalist = document.querySelector('.myclass0');
    for(var i=0; i<datalist.options.length; i++){
    	if(input.value ===datalist.options[i].value){
        optionFound = true;
        break;
        }
        }
        if(!optionFound){
        input.value = '';
        }
})

$(document).on('change','#myinput1', function(){
    
    var input = document.querySelector('#myinput1');
    var optionFound = false;
    var datalist = document.querySelector('.myclass1');
    for(var i=0; i<datalist.options.length; i++){
    	if(input.value ===datalist.options[i].value){
        optionFound = true;
        break;
        }
        }
        if(!optionFound){
        input.value = '';
        }
})

$(document).on('change','#myinput2', function(){
   
    var input = document.querySelector('#myinput2');
    var optionFound = false;
    var datalist = document.querySelector('.myclass2');
    for(var i=0; i<datalist.options.length; i++){
    	if(input.value ===datalist.options[i].value){
        optionFound = true;
        break;
        }
        }
        if(!optionFound){
        input.value = '';
        }
})
//End input box option validate jquery

function AddFrmCookie(){
    if($('.INP0xDYN').val()!='' || $('.INP1xDYN').val()!='' || $('.INP2xDYN').val()!=''){
        return false
    }
    SET_COOKIES.forEach(function (arrayItem)
    {                                              
        console.log(arrayItem)  
        switch(arrayItem)
        {
            case 'SUTcookie':
                $('#SUTTime').text($.cookie(arrayItem));	    break   
            case 'LAYER0':
                $('.INP0xDYN').val($.cookie(arrayItem));		break
            case 'LAYER1':
                $('.INP1xDYN').val($.cookie(arrayItem));		break
            case 'LAYER2':
                $('.INP2xDYN').val($.cookie(arrayItem));		break
            case 'LAYER3':
                $('.INP3xDYN').val($.cookie(arrayItem));  	    break
            case 'LAYER4':
                $('.INP4xDYN').val($.cookie(arrayItem));		break		
            case 'LAYER5':
                $('.INP5xDYN').text($.cookie(arrayItem));		break								
            case 'LAYER6':
                $('.INP6xDYN').val($.cookie(arrayItem));		break
            case 'LAYER7':
                $('.INP7xDYN').val($.cookie(arrayItem));		break                                                     
            default:
                console.log('defaults')
        }
    })
}
//"<div class='BOX_4'><input class='FilterInp' list='FILTERLAYERLIST'><datalist id=FILTERLAYERLIST></input></div>"
function SHOWGRAPHICS()
{

    var html=
    "<hr>"+    
    "<div class='BOX_4'><table class='REPORToptionS'><thead><th>FROM</th><th>TO</th></thead><tbody><tr><td><input class='FROMDATE' type='date'></input></td><td><input class='TODATE' type='date'></input></td></tr></tbody></table></div>"
    $('.BOX_2').after(html);

    var html=                                                
    "<tr>"+
    "<td><span class='COL_0'><p class='PROHEADER'>Process Time </p><br><p class='PROVALUE'></p><button class='DOWNLOAD_PRO0'>csv</button></span><button class='DOWNLOAD_PDF0' >PDF</button></td><td><span class='COL_1'><p class='PROHEADER'>Non Process Time</p><p class='NPROVALUE'></p><button class='DOWNLOAD_PRO1'>csv</button><button class='DOWNLOAD_PDF1' >PDF</button></span></td><td><span class='COL_2'><p class='PROHEADER'>Idle Time(2 mins)</p><br><p class='TPROVALUE'></p><button class='DOWNLOAD_PRO2'>csv</button><button class='DOWNLOAD_PDF2' >PDF</button></span></td>/tr>"
    $('.DYN_TBODY3').append(html);
//&#10162
}

function PUBLISHDATA(){

    var USERNAME=param[4]
    let date=new Date()
    console.log(date)
    var DEFINEDTYPE='NONPROCESS'
    
    
        console.log('Empty')      
        if (typeof $.cookie('STARTDATE')==='undefined' && typeof $.cookie('ENDDATE')==='undefined' )
        {
            $('.FROMDATE').val(moment().format('YYYY-MM-DD'))        
            $('.TODATE').val(moment().format('YYYY-MM-DD'))
        }else{
            $('.FROMDATE').val($.cookie("STARTDATE"))        
            $('.TODATE').val($.cookie("ENDDATE"))
        }


    var STARTDate=$('.FROMDATE').val()
    var ENDDate=$('.TODATE').val()    
    $.ajax
    ({
        url : '/api/USERSgraph',
        data:{'xUSER':USERNAME,'TYPE':DEFINEDTYPE,'SDATE':STARTDate,'EDATE':ENDDate},
        success:function(data)
        {
            try{
                console.log(data['PREPPROCOUNT'])
                var idle_Array = [];var NONPROCESS_Array = [];var PROCESS_Array = [];
                lenx=data['PREPPROCOUNT'].length
                for(var x=0;x<lenx;x++){
                    switch(data['PREPPROCOUNT'][x][0])
                    {
                        case "NON PROCESS":
                            if(data['PREPPROCOUNT'][x][0]=="NON PROCESS"){
                                NONPROCESS_Array.push(data['PREPPROCOUNT'][x][1])                                                
                            }    
                        case 'PROCESS':
                            if(data['PREPPROCOUNT'][x][0]=="PROCESS"){
                                PROCESS_Array.push(data['PREPPROCOUNT'][x][1])                                                
                            }    
                        case 'IDLE':
                            if(data['PREPPROCOUNT'][x][0]=="IDLE"){
                                idle_Array.push(data['PREPPROCOUNT'][x][1])                                                
                            }                                        
                    }

                    
                }
                console.log(PROCESS_Array)
                console.log(NONPROCESS_Array)
                console.log(idle_Array)

                const anyPRO =    PROCESS_Array
                const PROsum = anyPRO.reduce((acc, time) => acc.add(moment.duration(time)), moment.duration());                
                console.log([Math.floor(PROsum.asHours()), PROsum.minutes(), PROsum.seconds()].join(':'));
                TOTAL_PROCESS_TIME=[Math.floor(PROsum.asHours()), PROsum.minutes(), PROsum.seconds()].join(':')
    
                const anyNPRO =    NONPROCESS_Array
                const NPROsum = anyNPRO.reduce((acc, time) => acc.add(moment.duration(time)), moment.duration());                
                console.log([Math.floor(NPROsum.asHours()), NPROsum.minutes(), NPROsum.seconds()].join(':'));
                TOTAL_NONPROCESS_TIME=[Math.floor(NPROsum.asHours()), NPROsum.minutes(), NPROsum.seconds()].join(':')

                const anyIDLE =    idle_Array
                const IDLEsum = anyIDLE.reduce((acc, time) => acc.add(moment.duration(time)), moment.duration());                
                console.log([Math.floor(IDLEsum.asHours()), IDLEsum.minutes(), IDLEsum.seconds()].join(':'));
                TOTAL_IDLE_TIME=[Math.floor(IDLEsum.asHours()), IDLEsum.minutes(), IDLEsum.seconds()].join(':')

                $('.PROVALUE').text(TOTAL_PROCESS_TIME)
                $('.NPROVALUE').text(TOTAL_NONPROCESS_TIME)
                $('.TPROVALUE').text(TOTAL_IDLE_TIME)

                console.log('Enter')
            }catch{
                console.log('Nill Data')
            }

        }})   
}
                    
//                const any = data['PREPPROCOUNT']
//                var TotalHrs=[Math.floor(sum.asHours()), sum.minutes()].join(':')

//                console.log(data['PREPPROCOUNT'])
//                console.log(data['PREPPROCOUNT'][0][1])
//                $('.PROVALUE').text(data['PREPPROCOUNT'][2][1])
//                $('.NPROVALUE').text(data['PREPPROCOUNT'][1][1])
//                $('.TPROVALUE').text(data['PREPPROCOUNT'][0][1])

$(document).on('change','.FROMDATE',function()
{
    var SXdate=$('.FROMDATE').val()
    $.cookie('STARTDATE',SXdate,{expires:1})
})
$(document).on('change','.TODATE',function()
{
    var EXdate=$('.TODATE').val()
    $.cookie('ENDDATE',EXdate,{expires:1})
})

$(document).on('click','.BREAKBTN',function()
{
                 
                    console.log($('.BREAKINFO').length )
                    if ($('.BREAKINFO').length == 0) {
                        var html=                                        
                        "<th>ACTUAL</th><th>SUT</th><th>SELECT A BREAK</th><th>REMARK IF ANY</th>"        
                        $('.DYN_THEAD2').append(html);  
                        if(LETSROCK=='PROCESS')
                        {
                            var html=                                        
                            "<td><span class='BREAKACTUAL'>00:00:00</span></td><td><span class='BREAKSUT'>00:00:00</span></td><td><input class='BREAKINFO' list='BREAKLAYERLIST'><datalist id=BREAKLAYERLIST></input></td><td><input class='REMARKINFO' type='text'></input></td><td><button class='RESUMEBTN'>RESUME <i class='material-icons'>"+ resumeIcon +"</i></button></td>"
                            $('.DYN_TBODY2').append(html);
                        }else{
                            var html=                                        
                            "<td><span class='BREAKACTUAL'>00:00:00</span></td><td><span class='BREAKSUT'>00:00:00</span></td><td><input class='BREAKINFO' list='BREAKLAYERLIST'><datalist id=BREAKLAYERLIST></input></td><td><input class='REMARKINFO' type='text'></input></td><td><button class='STOPBREAKBTN'>STOP <i class='material-icons'>"+ stopxIcon +"</i></button></td>"
                            $('.DYN_TBODY2').append(html);

                        }

                        console.log('Break Clicked')
                    }
                
})

$(document).on('click','.BREAKBTN',function()
{
    clearInterval(myInterval)
    var USERNAME=param[4]
    var DEFINEDTYPE='NONPROCESS'
    console.log('BreakTest')
    
    var TEAMNAME= $.cookie('TEAM')+'.json'  
    var Tname=$.cookie('TEAM')       
    var XVAL='NON PROCESS'
      
    $.ajax
    ({
        url : '/api/STARTPROCESS',
        data:{'xUSER':USERNAME,'TYPE':DEFINEDTYPE},
        success:function(data)
        {
            $.removeCookie('STATUS', { path: '/' })
            $.cookie('STATUS',DEFINEDTYPE,{expires:1})
            window.location.reload()

        }
    })    
    $.ajax
    ({
                url : '/api/LIVExDATA',
                data:{'xUSER':USERNAME,'xTEAM':TEAMNAME,'TYPE':DEFINEDTYPE,'DATAACTIVE':XVAL,'XTEAMX':Tname},
                success:function(data)
                {            
                    console.log('LIVE Data Updated')
                }
    })           
    
})


$(document).on('click','.STOPBREAKBTN',function()
{
    if($('.BREAKINFO').val().length==0){
        
        $('.BREAKINFO').css('background-color','#f69606')
        return false
    }
    $.removeCookie('STATUS')
    $.removeCookie('STATUS', { path: '/' })
    var USERNAME=param[4]    
    var DEFINEDTYPE='ONLY_NONPROCESS'
    var TEAMNAME=$.cookie("TEAM")
    var UNIQUEXNO=$.cookie("UNIQNEX")
    var TimeTaken=$.cookie('TIMESPENTONBREAK')
    var BREAKINFOR=$('.BREAKINFO').val()
    var BREAKREMARK=$('.REMARKINFO').val()
    $.getJSON('/static/JSONFOLDER/USER_JSON/'+FILENAMEX,function(data){   
        let startDATE=data[2]['NONPROCESS'][0]['STARTDATE']
        let startTime=data[2]['NONPROCESS'][1]['STARTED_AT']
        $.ajax
        ({
            url : '/api/STOPPROCESS',
            data:{'xUSER':USERNAME,'xTEAM':TEAMNAME,'TYPE':DEFINEDTYPE,'UNIQ':UNIQUEXNO,'START':startTime,'SDATE':startDATE,'ACTUALTIME':TimeTaken,'BRINFO':BREAKINFOR,'BRREMARKS':BREAKREMARK},
            success:function(data)
            {
                window.location.reload()
            }})
    })
    
})

$(document).on('click','.RESUMEBTN',function()
{
	setTimeout(function () { $(this).prop('disabled', false); }, 500)
    if($('.BREAKINFO').val().length==0){
        
        $('.BREAKINFO').css('background-color','#f69606')
        return false
    }
    $.cookie('STATUS','RESUME',{expires:1})
    var USERNAME=param[4]
    var DEFINEDTYPE='RESUME'
    var TEAMNAME=$.cookie("TEAM")
    var UNIQUEXNO=$.cookie("UNIQNEX")
    var TimeTaken=$.cookie('TIMESPENTONBREAK')
    var BREAKINFOR=$('.BREAKINFO').val()
    var BREAKREMARK=$('.REMARKINFO').val()


    
    var XVAL='NOT YET SELECETD'

    $.ajax
    ({
        url : '/api/STARTPROCESS',
        data:{'xUSER':USERNAME,'TYPE':DEFINEDTYPE,'TIMETAKEN':TimeTaken},
        success:function(data)
        {

            $.cookie('STATUS',DEFINEDTYPE,{expires:1})
            $.getJSON('/static/JSONFOLDER/USER_JSON/'+FILENAMEX,function(data){   
                let startDATE=data[2]['NONPROCESS'][0]['STARTDATE']
                let startTime=data[2]['NONPROCESS'][1]['STARTED_AT']
            $.ajax
            ({
                url : '/api/STOPPROCESS',
                data:{'xUSER':USERNAME,'xTEAM':TEAMNAME,'TYPE':DEFINEDTYPE,'UNIQ':UNIQUEXNO,'START':startTime,'SDATE':startDATE,'ACTUALTIME':TimeTaken,'BRINFO':BREAKINFOR,'BRREMARKS':BREAKREMARK},
                success:function(data)
                {
                    $.ajax
                    ({
                        url : '/api/LIVExDATA',
                        data:{'xUSER':USERNAME,'xTEAM':TEAMNAME,'TYPE':'PROCESS','DATAACTIVE':XVAL,'XTEAMX':TEAMNAME},
                        success:function(data)
                        {            
                            console.log('LIVE Data Updated')
                            window.location.reload()
                        }})                                                      
                    

                }})
            })
         
        }})         
})


$(document).on('click','.STARTBTN',function()
{
    var input_value0 = $('#myinput0').val();
    var input_value1 = $('#myinput1').val();
    var input_value2 = $('#myinput2').val();
    if(input_value0 == "" || input_value1 == "" ||input_value2 == ""){
        alert("Fill All Input Values");
        $('.DYN_TBODY1 input[type="text"]').val('');
    }else{
    var USERNAME=param[4]
    var DEFINEDTYPE='PROCESS'
    
    var TEAMNAME= $.cookie('TEAM')+'.json'  
    var Tname=$.cookie('TEAM')      
    var XVAL
    
    MArray=['.INP0xDYN','.INP1xDYN','.INP2xDYN']
    MArray.forEach(function (arrayItem) {
        var x = $(arrayItem).val();
        console.log(x)
        if ( x.length != 0 )
        {
            XVAL=x
        }})
        console.log(typeof(XVAL))
        
        if(typeof(XVAL)=='undefined'){
            XVAL='NOT YET SELECETD'
        }
    
    console.log('test')
    $.ajax
    ({
        url : '/api/STARTPROCESS',
        data:{'xUSER':USERNAME,'TYPE':DEFINEDTYPE},
        success:function(data)
        {
            $.cookie('STATUS','PROCESS',{expires:1})
            localStorage.setItem('TYPE_OF_ACTIVITY', 'PROCESS')
            $.cookie('UNIQNEX',data['UNIQNESS_IS_MAINTAINED'],{expires:1,path: '/'})
            window.location.reload()
        }})   
    $.ajax
    ({
            url : '/api/LIVExDATA',
            data:{'xUSER':USERNAME,'xTEAM':TEAMNAME,'TYPE':DEFINEDTYPE,'DATAACTIVE':XVAL,'XTEAMX':Tname},
            success:function(data)
            {            
                console.log('LIVE Data Updated')
            }}) 
        }        
})


$(document).on('change','.UNITS',function()
{
    var hms = $.cookie('SUTcookie')
    
                                    
    var time=hms
    var a = time.split(':')
    console.log(a)
    var seconds = (+a[0]) * 60 * 60 + (+a[1]) * 60 + (+a[2]); 
    var newSeconds= $(".UNITS").val()*seconds;
    
    var date = new Date(newSeconds * 1000);
    var hh = date.getUTCHours();
    var mm = date.getUTCMinutes();
    var ss = date.getSeconds();
    if (hh < 10) {hh = "0"+hh;}
    if (mm < 10) {mm = "0"+mm;}
    if (ss < 10) {ss = "0"+ss;}
    var t = hh+":"+mm+":"+ss;      
    $("#SUTTime").text(t)                     
    console.log(t)                            
})
$(document).on('dblclick','.SAVEBTN',function()
{
	console.log('double click')
        $('.material-iconsa').remove()
        $('.infotexta').remove()
        $('.material-iconsB').remove()
        $('.infotextB').remove()
        $('.material-iconsx').remove()
        $('.infotext').remove()
        $('.info').css('display','');
        console.log('Success')            
        var html="<i class='material-iconsB' >"+ WARNING +"</i><p class='infotextB'>Double click Not Allowed !</p>"
        $('.info').append(html);
        setTimeout(function() { $('.info'). hide(); }, 5000);
})


$(document).on('click','.SAVEBTN',function()
{
	setTimeout(function () { $(this).prop('disabled', false); }, 500)

                        if($('#ActualTime').text()=='00:00:00'){
                            return false
                        }
			var VERTICLENAME= $.cookie('SELECTEDVERTICLE')
                        let xres=''
                        MArray=['.INP0xDYN','.INP1xDYN','.INP2xDYN']
						MArray.forEach(function (arrayItem) {
							var x = $(arrayItem).val();
                            console.log(x)
							if ( x.length == 0 )
							{
								   $(arrayItem).css('background-color','#FFB011');
								   xres='Dont'
							}
							else
							{
								   $(arrayItem).css('background-color','inherit')                    
							}
							});
							
							switch(xres)
							{
								   case 'Dont':
										 alert('Null Values Not Accepted!')
										 return false
								   default:
                                        var USERNAME=param[4]
                                        var TEAMNAME=$.cookie("TEAM")
                                        var DEFINEDTYPE='PROCESS'
                                        var UNIQUEXNO=$.cookie("UNIQNEX")
                                        var TEAMFILENAMEX= $.cookie('TEAM')+'.json' 
                                        var UNIT=$('.UNITS').val()
                                        var xACTUAL=$('#ActualTime').text()
                                        var xXSUTXx=$.cookie('SUTcookie')
                                        var Multiply=$('#SUTTime').text()    
                                        var LAYERX0=$.cookie('LAYER0')
                                        var LAYERX1=$.cookie('LAYER1')
                                        var LAYERX2=$.cookie('LAYER2')
                                        var LAYERX3=$.cookie('LAYER3')
                                        var LAYERX4=$('.INP3xDYN').val()
                                        var FILENAMEX=param[4]+'log.json'
                            }
                            
    					EST_SUT=$("#SUTTime").text()
						RUNTIME=$("#ActualTime").text()
						const [hours1, minutes1, seconds1] = EST_SUT.split(':');
						const [hours2, minutes2, seconds2] = RUNTIME.split(':');						
						const XEST_SUT = new Date(2022, 0, 1, +hours1, +minutes1, +seconds1);
						const XRUNTIME = new Date(2022, 0, 1, +hours2, +minutes2, +seconds2);						
						console.log('SUT'+XEST_SUT)
						console.log('ACTUAL'+XRUNTIME)
                        if(EST_SUT!='00:00:00')
                        {                        
                            if ($(".REMARKINFO").length == 0)
                            {
                                if (XEST_SUT.getTime() < XRUNTIME.getTime()) 
                                {
//                                    alert('SUT exceeded Provide Reason !')
				        $('.material-iconsa').remove()
				        $('.infotexta').remove()
				        $('.material-iconsB').remove()
				        $('.infotextB').remove()
				        $('.material-iconsx').remove()
				        $('.infotext').remove()
				        $('.info').css('display','');
				        console.log('Success')            
				        var html="<i class='material-iconsB' >"+ WARNING +"</i><p class='infotextB'>SUT exceeded Provide Reason !</p>"
				        $('.info').append(html);
				        setTimeout(function() { $('.info'). hide(); }, 5000);
                                        for (var i = 0; i< 1; i++)
                                        {   
                                                    
                                            var html=
                                            "<div class='REMARKMODAL'>"+
                                                "<div class='Rcontains'>"+                                
                                                "<input class='REMARKINFO' placeholder='Reason For abnormal Exit or exceeding SUT' list='REMARKLAYERLIST'><datalist id=REMARKLAYERLIST></input>"
                                                +"</div>"
                                            +"</div>"
                                            $('.BOX_1').first().after(html);
                                            FILL_REMARKANDBRK()
                                            return false
                                        }                                                             
                                }else{
                                        let a=XEST_SUT.getTime();let b=XRUNTIME.getTime()
                                        let PERCENTAGE=(Math.abs(a-b)/1000/100).toFixed(2)
                                        console.log(PERCENTAGE)
                                        //return false
                                        if(PERCENTAGE>1.75 || PERCENTAGE<=0.25){
                                            $('.REMARKMODAL').remove()
                                            var html=
                                            "<div class='REMARKMODAL'>"+
                                                "<div class='Rcontains'>"+                                
                                                "<input class='REMARKINFO' placeholder='Reason For abnormal Exit or exceeding SUT' list='REMARKLAYERLIST'><datalist id=REMARKLAYERLIST></input>"
                                                +"</div>"
                                            +"</div>"
                                            $('.BOX_1').first().after(html);
                                            FILL_REMARKANDBRK()
                                            return false                                                                        
                                        }
                                    }
                            }else{                            
                                

                                if ($(".REMARKINFO").val().length == 0){
				        $('.material-iconsa').remove()
				        $('.infotexta').remove()
				        $('.material-iconsx').remove()
				        $('.infotexta').remove()
				        $('.material-iconsB').remove()
				        $('.infotextB').remove()
				        $('.info').css('display','');
				        console.log('Success')            
				        var html="<i class='material-iconsx' >"+ NOTIFICATIONX +"</i><p class='infotexta'>Kindly Provide Reason for Exceeding SUT</p>"
				        $('.info').append(html);
				        setTimeout(function() { $('.info'). hide(); }, 8000);
//                                    alert('Null Value not Accepted')
                                    return false
                                }
                            }
                        }else{
                            if(VERTICLENAME=='AA_COMPLIANCE')
                            {
                                if ($(".STATUSINFO").length == 0)
                                {
                                    $('.STATUSMODAL').remove()
                                    for (var i = 0; i< 1; i++)
                                    {                                               
                                        var html=
                                        "<div class='STATUSMODAL'>"+
                                            "<div class='Scontains'>"+                                
                                            "<input class='STATUSINFO' placeholder='Select STATUS' list='STATUSLAYERLIST'><datalist id=STATUSLAYERLIST></input>"
                                            +"</div>"
                                        +"</div>"
                                        $('.BOX_1').first().after(html);
                                        FILL_STATUS()
                                        return false
                                    }
                                }else
                                {
                                    if ($('.USERCODE').val()=='Select')
                                    {
                                        $('.material-iconsa').remove()
                                        $('.infotexta').remove()
                                        $('.material-iconsx').remove()
                                        $('.infotexta').remove()
                                        $('.material-iconsB').remove()
                                        $('.infotextB').remove()
                                        $('.info').css('display','');
                                        console.log('Success')            
                                        var html="<i class='material-iconsx' >"+ NOTIFICATIONX +"</i><p class='infotexta'>Select ROLE</p>"
                                        $('.info').append(html);
                                        setTimeout(function() { $('.info'). hide(); }, 5000);
                                        return false
                                    }

                                    if ($(".STATUSINFO").val().length == 0) {

                                        $('.material-iconsa').remove()
                                        $('.infotexta').remove()
                                        $('.material-iconsx').remove()
                                        $('.infotexta').remove()
                                        $('.material-iconsB').remove()
                                        $('.infotextB').remove()
                                        $('.info').css('display','');
                                        console.log('Success')            
                                        var html="<i class='material-iconsx' >"+ NOTIFICATIONX +"</i><p class='infotexta'>Kindly Select a Status</p>"
                                        $('.info').append(html);
                                        setTimeout(function() { $('.info'). hide(); }, 5000);
                                        return false
                                    }
                                    console.log('Status Updated')
                                }

                            }else{
                                console.log('NO remark for actual')
                            }
                            }
        if($(".REMARKINFO").length == 0){
            var REMARKx='No remarks'
        }else{
            var REMARKx=$(".REMARKINFO").val()
        }
        $(".SAVEBTN").prop('disabled', true)                         
        $.getJSON('/static/JSONFOLDER/USER_JSON/'+FILENAMEX,function(data){          
        var STARTXDATE=data[1]['PROCESS'][0]['STARTDATE']     
        var STARTXTIME=data[1]['PROCESS'][1]['STARTED_AT']
        console.log(STARTXTIME)
//	var Multiply=$('#SUTTime').text()
        var time=moment(xXSUTXx,'HH:mm:ss').format('HH:mm:ss');var a=time.split(':');var seconds = (+a[0]) * 60 * 60 + (+a[1]) * 60 + (+a[2]);             
        var newSeconds= $(".UNITS").val()*seconds;var date = new Date(newSeconds * 1000);
        var hh = date.getUTCHours();var mm = date.getUTCMinutes();var ss = date.getSeconds();
        if (hh < 10) {hh = "0"+hh;}; if (mm < 10) {mm = "0"+mm;};if (ss < 10) {ss = "0"+ss;}; var t = hh+":"+mm+":"+ss;    
        var Multiply=t
	if(Multiply=='NaN:NaN:NaN'){
		Multiply='00:00:00'
			}
        if(VERTICLENAME=='AA_COMPLIANCE')
        {
            USERTYPE=$('.USERCODE').val();STATUSX=$('.STATUSINFO').val()
            REQ_DATA={'xUSER':USERNAME,'xTEAM':TEAMNAME,'TYPE':DEFINEDTYPE,'UNIQ':UNIQUEXNO,'START':STARTXTIME,'SDATE':STARTXDATE,'ACTUALTIME':xACTUAL,'SUTTIME':xXSUTXx,'NOOFUNIT':UNIT,'MULTIPLX':Multiply,'LAYER0':LAYERX0,'LAYER1':LAYERX1,'LAYER2':LAYERX2,'LAYER3':LAYERX3,'REMARKS':REMARKx,'REMARKX':LAYERX4,'TYPEOFUSER':USERTYPE,'JOBSTATUS':STATUSX}
        }
        else{
            REQ_DATA={'xUSER':USERNAME,'xTEAM':TEAMNAME,'TYPE':DEFINEDTYPE,'UNIQ':UNIQUEXNO,'START':STARTXTIME,'SDATE':STARTXDATE,'ACTUALTIME':xACTUAL,'SUTTIME':xXSUTXx,'NOOFUNIT':UNIT,'MULTIPLX':Multiply,'LAYER0':LAYERX0,'LAYER1':LAYERX1,'LAYER2':LAYERX2,'LAYER3':LAYERX3,'REMARKS':REMARKx,'REMARKX':LAYERX4}
        }        
        
    $.ajax
    ({
        url : '/api/STOPPROCESS',
        data:REQ_DATA,
        success:function(data)
        {            
            $.removeCookie('STATUS')
            $.removeCookie('STATUS', { path: '/' })
            $.removeCookie('UNIQNEX', { path: '/' })
            $.removeCookie('SUTcookie')
            $.removeCookie('LAYER2')
            $.removeCookie('LAYER1')
            $.removeCookie('LAYER0')
            $.removeCookie('TIMESPENTONBREAK')              
            window.localStorage.removeItem('TYPE_OF_ACTIVITY')
            window.location.reload()
        }})  
    })

})    


$(document).on('change','.INP0xDYN',function(event)
{
    
    var TEAMNAME= $.cookie('TEAM')+'.json'        
    var VERTICLENAME= $.cookie('SELECTEDVERTICLE')
    var map = {};
    $.getJSON('/static/JSONFOLDER/'+TEAMNAME,function(data){

        
        
        len=data[1]['LAYER'][1]['LAYERx2']
       
        $('.INP1xDYN').val(null);$('#LAYERLIST1').empty()
        $('.INP2xDYN').val(null);$('#LAYERLIST2').empty()
        for (var i=0;i<len.length;i++)
        {
            if(VERTICLENAME!='AA_COMPLIANCE'){
                
                FIND=len[i]['FIND']
            }else{
                
                FIND='MANIBHARATHI'
                var BRKXLayer=len[i]['LAYER2']
                let BRKXlist = document.getElementById('LAYERLIST1');
                var option = document.createElement('option');
                option.value = BRKXLayer;
                BRKXlist.appendChild(option);  	

                if (map[option.value]) {
                    $(option).remove()
                }
                map[option.value] = true;
            }
            
            if($('.INP0xDYN').val()==FIND)
            {
                
                console.log(len[i]['LAYER2'])    
                var BRKXLayer=len[i]['LAYER2']
                let BRKXlist = document.getElementById('LAYERLIST1');
                var option = document.createElement('option');
                option.value = BRKXLayer;
                BRKXlist.appendChild(option);  		
                
                if (map[option.value]) {
                    $(option).remove()
                }
                map[option.value] = true;

            }
                                         

        }
        
    })
    

})

/*
$(document).on('change','.INP1xDYN',function(event)
{
    
    var TEAMNAME= $.cookie('TEAM')+'.json'    
    var VERTICLENAME= $.cookie('SELECTEDVERTICLE')    
    var map = {};
    $.getJSON('/static/JSONFOLDER/'+TEAMNAME,function(data){
        
        len=data[1]['LAYER'][2]['LAYERx3']
        
        $('.INP2xDYN').val(null);$('#LAYERLIST2').empty()
        for (var i=0;i<len.length;i++)
        {
            if(VERTICLENAME!='AA_COMPLIANCE'){            
                FIND=len[i]['FIND']
                FINDxM=len[i]['FINDM']                    
            }else{
                console.log('test')
                FIND=len[i]['FIND']
                FINDxM='MANIBHARATHI'
                *****
                var BRKXLayer=len[i]['LAYER3']
                let BRKXlist = document.getElementById('LAYERLIST2');
                var option = document.createElement('option');
                option.value = BRKXLayer.toUpperCase();
                BRKXlist.appendChild(option);        
                
                if (map[option.value]) {
                    $(option).remove()
                }
                map[option.value] = true;
                *****
            }
            
            if($('.INP1xDYN').val()==FIND && $('.INP0xDYN').val()==FINDxM)
            {
                console.log(len[i]['LAYER3'])    
                var BRKXLayer=len[i]['LAYER3']
                let BRKXlist = document.getElementById('LAYERLIST2');
                var option = document.createElement('option');
                option.value = BRKXLayer.toUpperCase();
                BRKXlist.appendChild(option);  				
                
                if (map[option.value]) {
                    $(option).remove()
                }
                map[option.value] = true;
            }
            
        }

        
    })



})
*/

$(document).on('change','.INP1xDYN',function(event)
{
    
    var TEAMNAME= $.cookie('TEAM')+'.json'    
    var VERTICLENAME= $.cookie('SELECTEDVERTICLE')    
    var map = {};
    $.getJSON('/static/JSONFOLDER/'+TEAMNAME,function(data){
        
        len=data[1]['LAYER'][2]['LAYERx3']
        
        $('.INP2xDYN').val(null);$('#LAYERLIST2').empty()
        for (var i=0;i<len.length;i++)
        {
            if(VERTICLENAME!='AA_COMPLIANCE'){            
                FIND=len[i]['FIND']
                FINDxM=len[i]['FINDM']                    
            }else{
                FIND=len[i]['FIND']
                FINDxM=len[i]['FINDM']
            if($('.INP1xDYN').val()==FIND && FINDxM=='MANIBHARATHI')
            {
                var BRKXLayer=len[i]['LAYER3']
                let BRKXlist = document.getElementById('LAYERLIST2');
                var option = document.createElement('option');
                option.value = BRKXLayer;
                BRKXlist.appendChild(option);        
                
                if (map[option.value]) {
                    $(option).remove()
                }
                map[option.value] = true;
		}
            }
            
            if($('.INP1xDYN').val()==FIND && $('.INP0xDYN').val()==FINDxM)
            {
                console.log(len[i]['LAYER3'])    
                var BRKXLayer=len[i]['LAYER3']
                let BRKXlist = document.getElementById('LAYERLIST2');
                var option = document.createElement('option');
                option.value = BRKXLayer;
                BRKXlist.appendChild(option);  				
                
                if (map[option.value]) {
                    $(option).remove()
                }
                map[option.value] = true;
            }            
        }  
    })
})
$(document).on('dblclick','.DYN_T1 .DYN_TBODY1 input',function(el)
{
    console.log($(el.target).attr('class'))
    if($(el.target).attr('class')=='UNITS'){
        return false
    }    
    $(el.target).val(null)
    $(el.target).focus()    
})


function ClearInpur(element)
{                
    element.value=""
    document.getElementById(element).focus();
} 

$(document).on('change','.DYN_T1 .DYN_TBODY1 input',function(el)
{

    console.log($(el.target).attr('class'))
    if($(el.target).attr('class')=='UNITS' || $(el.target).attr('class')=='INP3xDYN'){
        return false
    }
    //console.log(el)
    var TEAMNAME= $.cookie('TEAM')+'.json'  
    var Tname=$.cookie('TEAM')      
    var DEFINEDTYPE='PROCESS'
    var USERNAME=param[4]
    var XVAL=$(el.target).val()
    $.getJSON('/static/JSONFOLDER/'+TEAMNAME,function(data){
        SUTLAYER=data[2]['SUTinfo']
        INPUTLYR=$(el.target).val()

        for (var i=0;i<SUTLAYER.length;i++)
            {
                
                $('#SUTTime').text(data[2]['SUTinfo'][i][INPUTLYR])
                var SUTvalue=$('#SUTTime').text()
                console.log(SUTvalue)
                $.cookie('SUTcookie',SUTvalue,{expires:1})
            }        
    })
    
    $.ajax
    ({
        url : '/api/LIVExDATA',
        data:{'xUSER':USERNAME,'xTEAM':TEAMNAME,'TYPE':DEFINEDTYPE,'DATAACTIVE':XVAL,'XTEAMX':Tname},
        success:function(data)
        {            
            console.log('LIVE Data Updated')
        }})
    
})

$(document).on('change','.DYN_T2 .DYN_TBODY2 input',function(el)
{

    console.log(el)
    var TEAMNAME= $.cookie('TEAM')+'.json'    
    var Tname=$.cookie('TEAM')        
    var DEFINEDTYPE='NONPROCESS'
    var USERNAME=param[4]
    var XVAL=$(el.target).val()
    var TEAMNAME= $.cookie('TEAM')+'.json'        
    $.getJSON('/static/JSONFOLDER/'+TEAMNAME,function(data){
        SUTLAYER=data[2]['SUTinfo']
        INPUTLYR=$(el.target).val()
        for (var i=0;i<SUTLAYER.length;i++)
            {
                
                $('.BREAKSUT').text(data[2]['SUTinfo'][i][INPUTLYR])
                var SUTvalue=$('.BREAKSUT').text()
//                console.log(SUTvalue)
                $.cookie('BREAKSUTcookie',SUTvalue,{expires:1})
            }        
    })
    $.ajax
    ({
        url : '/api/GETUSERLIVEDATA',
        data:{'xUSER':USERNAME,'xTEAM':TEAMNAME,'TYPE':DEFINEDTYPE,'DATAACTIVE':XVAL,'XTEAMX':Tname},
        success:function(data)
        {            
            console.log('LIVE Data Updated')
        }})
})

$(document).on('hover','.DYN_T2 .DYN_TBODY2 input',function(el)
{
    console.log('Testing')
})    

$(document).on('change','.LAYERxDYN0',function(el)
{
    $.cookie('LAYER0',$(el.target).val(),{expires:1})
})

$(document).on('change','.LAYERxDYN1',function(el)
{
    $.cookie('LAYER1',$(el.target).val(),{expires:1})
})


$(document).on('change','.LAYERxDYN2',function(el)
{
    $.cookie('LAYER2',$(el.target).val(),{expires:1})
})

$(document).on('change','.LAYERxDYN3',function(el)
{
    $.cookie('LAYER3',$(el.target).val(),{expires:1})
})

$(document).on('change','.LAYERxDYN4',function(el)
{
    $.cookie('LAYER4',$(el.target).val(),{expires:1})
})

$(document).on('change','.LAYERxDYN5',function(el)
{
    $.cookie('LAYER5',$(el.target).val(),{expires:1})
})

$(document).on('change','.LAYERxDYN6',function(el)
{
    $.cookie('LAYER6',$(el.target).val(),{expires:1})
})


$(document).on('click','.LOGIN',function()
{
    if($('.INP_1').val() ==''){
        alert('select any One')
        $('.INP_1').focus()
        return false
    }
    var USERNAME=param[4]
    var SELECTEDTEAM=$('.INP_1').val()

    console.log(USERNAME)
    $.ajax
    ({
        url : '/api/loginWEB',
        data:{'xUSER':USERNAME,'xTEAM':SELECTEDTEAM},
        success:function(data)
        {            
            console.log(data['DETAILS'])
            window.location.reload()
        }
        
    })

})

$(document).on('click','.LOGOUT',function()
{
    if($('.BREAKACTUAL').text()!=''){
        console.log('empty')
    }
    if($('#ActualTime').text()!='00:00:00' || $('.BREAKACTUAL').text()!='')
    {
        $('.material-iconsx').remove()
        $('.infotext').remove()
        $('.material-iconsB').remove()
        $('.infotextB').remove()
        $('.material-iconsa').remove()
        $('.infotexta').remove()
        $('.info').css('display','');
        console.log('Success')            
        var html="<i class='material-iconsx' >"+ WARNING +"</i><p class='infotext'>Unable to Log out ,Kindly Stop Current Activity</p>"
        $('.info').append(html);
        setTimeout(function() { $('.info'). hide(); }, 5000);
//        alert('Unable to Log out ,Kindly Stop Current Activity')
//        alert($('#ActualTime').text())
//        alert($('.BREAKACTUAL').text())
        return false

    }
    var USERNAME=param[4]
    var SELECTEDTEAM=$('.INP_1').val()
    var TIMESPENT=document.title
    $.ajax
    ({

        url : '/api/logoutWEB',
        data:{'xUSER':USERNAME,'xTEAM':SELECTEDTEAM},
        success:function(data)
        {
            $.removeCookie('STATUS')  
            $.removeCookie('STATUS', { path: '/' })            
            $.removeCookie('PREV_SELECTED_TEAM', { path: '/' })
            $.removeCookie('SELECTEDVERTICLE', { path: '/' })            
            $.removeCookie('TIMESPENTONBREAK')  
            $.removeCookie('TEAM')   
            $.removeCookie('STARTDATE')   
            $.removeCookie('ENDDATE')   
            $.removeCookie('BREAKSUTcookie')              
            $.ajax({
                url:'/api/logoutX',
                data:{'xUSER':USERNAME,'xTEAM':SELECTEDTEAM,'TOTALTIME':TIMESPENT},   
                success:function(data){
                    window.location.reload()               
                    //'http://127.0.0.1:5000/'
		    console.log(param[0]+param[1]+param[2])
		    redirect_to=param[0]+'//'+param[1]+param[2]
		    $(location).prop('href',redirect_to)
/*
		    try{
                    $(location).prop('href', 'https://tools.sundarambusinessservices.com:631/')
			}
			catch{
                    $(location).prop('href', 'http://10.9.55.62:50990/')
			}
*/
                }
            })
        }})


})

setInterval(
	async function(){
        console.log('Timer')

 //       return false
        if(typeof param[4]==='undefined'){        
            return false            
        }
        var TEAMNAME= $.cookie('TEAM')+'.json'      
        var Tname=$.cookie('TEAM')  
        var XDEFINEDTYPE='IDLE'
        var XUSERNAME=param[4]
        var XVAL='IDLE TIME'
        if ( typeof $.cookie('STATUS')==='undefined' && $('.MODAL').length==0 ){
//                console.log('Modal')
                var USERNAME=param[4]
                var DEFINEDTYPE='IDLE'
//                console.log('BreakTest')
                $.cookie('STATUS',DEFINEDTYPE,{expires:1})                        
         
                $.ajax
                ({
                    url : '/api/STARTPROCESS',
                    data:{'xUSER':USERNAME,'TYPE':DEFINEDTYPE},
                    success:function(data)
                    {
            
                        $.cookie('STATUS',DEFINEDTYPE,{expires:1})
                        window.location.reload()

            }})  
            $.ajax
            ({
                url : '/api/LIVExDATA',
                data:{'xUSER':XUSERNAME,'xTEAM':TEAMNAME,'TYPE':XDEFINEDTYPE,'DATAACTIVE':XVAL,'XTEAMX':Tname},
                success:function(data)
                {            
                    console.log('LIVE Data Updated')
                }})
        }
    },2*60*1000)

$(document).on('click','.STOPIDLEBREAKBTN',function()
{
    if($('.REMARKINFO').val()==''){
        $('.REMARKINFO').attr("placeholder", "Kindly provide Reason")
        $('.REMARKINFO').css('background-color','#FFB011')
        setInterval(function(){
            $('.REMARKINFO').css('background-color','white');
            setTimeout(function(){
                $('.REMARKINFO').css('background-color','#FFB011');
            },500);
        },1000);        
        return false
    }
    $.removeCookie('STATUS')
    $.removeCookie('STATUS', { path: '/' })
    var USERNAME=param[4]
    var DEFINEDTYPE='IDLE'
    var TEAMNAME=$.cookie("TEAM")
    var UNIQUEXNO=$.cookie("UNIQNEX")
    var BREAKINFOR=$('.REMARKINFO').val()
    var TimeTaken=$.cookie('TIMESPENTONBREAK')
    $.getJSON('/static/JSONFOLDER/USER_JSON/'+FILENAMEX,function(data){   
        let startDATE=data[2]['NONPROCESS'][0]['STARTDATE']
        let startTime=data[2]['NONPROCESS'][1]['STARTED_AT']
        $.ajax
        ({
            url : '/api/STOPPROCESS',
            data:{'xUSER':USERNAME,'xTEAM':TEAMNAME,'TYPE':DEFINEDTYPE,'UNIQ':UNIQUEXNO,'START':startTime,'SDATE':startDATE,'ACTUALTIME':TimeTaken,'IDELREASON':BREAKINFOR},
            success:function(data)
            {             
                $.removeCookie('STATUS')  
                $.removeCookie('STATUS', { path: '/' })
                window.location.reload()
            }})
    })
    
})
$(document).on('change','#USER_MODE',function()
{
    switch($(this).val())
    {
        case 'Employee':
            $('.SHOWHIDDEN_LAYER').css('display','')
            $('.SHOWHIDDEN_HEADER').css('display','')
            $('.SHOWHIDDEN_LAYER0').css('display','')
            $('.SHOWHIDDEN_HEADER0').css('display','')
            break
        case 'Manager':
            $('.SHOWHIDDEN_LAYER').css('display','none')
            $('.SHOWHIDDEN_HEADER').css('display','none')            
            $('.SHOWHIDDEN_LAYER0').css('display','')
            $('.SHOWHIDDEN_HEADER0').css('display','')
            break
        default:
            $('.SHOWHIDDEN_LAYER').css('display','none')
            $('.SHOWHIDDEN_HEADER').css('display','none')
            $('.SHOWHIDDEN_LAYER0').css('display','none')
            $('.SHOWHIDDEN_HEADER0').css('display','none')
    }
/*
    if($('#USER_MODE').val()=='Employee'||$('#USER_MODE').val()=='Manager'){
        $('.SHOWHIDDEN_LAYER').css('display','')
        $('.SHOWHIDDEN_HEADER').css('display','')
        $('.SHOWHIDDEN_LAYER0').css('display','')
        $('.SHOWHIDDEN_HEADER0').css('display','')
    }else{
        $('.SHOWHIDDEN_LAYER').css('display','none')
        $('.SHOWHIDDEN_HEADER').css('display','none')
        $('.SHOWHIDDEN_LAYER0').css('display','none')
        $('.SHOWHIDDEN_HEADER0').css('display','none')
    }    
*/
})


$(document).on('change','#URNAME',function()
{
    USERNAME=$('#URNAME').val()
    $.ajax
    ({
        url : '/set',
        data:{'xUSER':USERNAME},
        success:function(data)
        {
            /*
            PROCESS=data['ONGOING_PROCESS']
            $.cookie('STATUS',PROCESS,{expires:1})
            */
           console.log('resumed')
	   FILL_VERTICAL()
        }})

})


$(document).on('change','.BREAKINFO',function()
{
	var MAINLYR = $('.BREAKINFO').val();		
		
			var val = MAINLYR
			var obj = $('#BREAKLAYERLIST').find("option[value='" + val + "']");
			if(obj != null && obj.length > 0){                           
				MAINLYR=MAINLYR				
			}
			else{
				alert("Not In List !");
				$('.BREAKINFO').val('')
				$(this).focus()
				return false
			}
})

$(document).on('change','.INP_1v',function()
{

    $('.INP_1').val(null);$('#dataXlist').empty()
	$.getJSON("/static/JSONFOLDER/TEAMvsVERTICLE.json", function(data)
			{
                console.log('in')
                var SELECTEDVERTICLE=$('.INP_1v').val()
				BREAKX_LAYERS=data[SELECTEDVERTICLE]
//                console.log(BREAKX_LAYERS)				
				REMARK_LAYERS=data.LIST_OF_REMARKS   
                $.cookie('SELECTEDVERTICLE',SELECTEDVERTICLE,{expires:10})
                console.log(SELECTEDVERTICLE)
				var l=0;var m=0
				for (var i=0;i<BREAKX_LAYERS.length;i++)
					{				                        
						var BRKXLayer=BREAKX_LAYERS[i].LIST
                        console.log(BRKXLayer)
						let BRKXlist = document.getElementById('dataXlist');
						var option = document.createElement('option');
						option.value = BRKXLayer;
						BRKXlist.appendChild(option);  						

					}
			})


})    
$(document).on('change','.INP_1',function()
{    
    var MATCH_TEAM= $.cookie('PREV_SELECTED_TEAM')
    var PAGE_STATUS= $.cookie('STATUS')
    var SELECTEDTEAM=$(this).val()
    if(typeof(MATCH_TEAM)!='undefined' && MATCH_TEAM!='')
    {
        if(SELECTEDTEAM!=MATCH_TEAM && $('#USER_MODE').val()=='Employee')
        {            
            
            $('#STATUS').text('Already in: '+MATCH_TEAM)
            $("#CLICKBTN").css('display','none')


        }else{
            $('#STATUS').text(null)
            $("#CLICKBTN").css('display','')
        }
    }
})
function DownloadPDF(pos){
    var url=document.URL;
    var urls=url.substr(url.lastIndexOf('?')+1,url.length);
    const param=url.split('/')                    
    var S_DATE=$('.FROMDATE').val();    
    var E_DATE=$('.TODATE').val();  
    var USERX=param[4]
    var xPOS=pos

    //var DATE_x=new Date();    
    var TEAM_x=$('.TEAMLAYERTXT').val();  
    console.log(TEAM_x)              
    
    $.ajax
    ({                        
        url :'/api/DownlUserX' ,                      
        type: 'GET',         
        xhrFields:{
            responseType: 'blob'
        },
        data:{'XTEAMX':TEAM_x,'SDATE':S_DATE,'EDATE':E_DATE,'XUSERX':USERX,'XTEAMX':TEAM_x,'Feature':xPOS},
        success: function(data) 
        {         
            var blob = data;
            console.log(data)
            var link=document.createElement('a');
            link.href=window.URL.createObjectURL(blob);
            link.download= new Date() + ".pdf";
            link.click();            
        }
    })
}
function DownloadCSV(pos)
{
    var url=document.URL;
    var urls=url.substr(url.lastIndexOf('?')+1,url.length);
    const param=url.split('/')                    
    var S_DATE=$('.FROMDATE').val();    
    var E_DATE=$('.TODATE').val();  
    var USERX=param[4]
    var xPOS=pos
    //var DATE_x=new Date();    
    var TEAM_x=$('.TEAMLAYERTXT').val();  
    console.log(TEAM_x)              
    
    $.ajax
    ({                        
        url :'/api/AdminDOWNLOADTEAM' ,                      
        type: 'GET',         
        xhrFields:{
            responseType: 'blob'
        },
        data:{'XTEAMX':TEAM_x,'SDATE':S_DATE,'EDATE':E_DATE,'XUSERX':USERX,'Feature':xPOS},
        success: function(data) 
        {         

            console.log(data)
            var blob = data;
            var downloadUrl = URL.createObjectURL(blob);
            var a = document.createElement("a");
            a.href = downloadUrl;
            a.style.display = 'none';
            a.download = "TEAM DAILY DATA.xls";
            document.body.appendChild(a);
            a.click();
//            setTimeout(() => { StopLoader_DONE(); }, 20000);
            
        }
    })
}
$(document).on('click','.DOWNLOAD_PDF0',function()
{
    DownloadPDF(0)
})

$(document).on('click','.DOWNLOAD_PDF1',function()
{
    DownloadPDF(1)
})

$(document).on('click','.DOWNLOAD_PDF2',function()
{
    DownloadPDF(2)
})

$(document).on('click','.DOWNLOAD_PRO0',function(){    
    DownloadCSV(0)
})

$(document).on('click','.DOWNLOAD_PRO1',function(){    
    DownloadCSV(1)
})

$(document).on('click','.DOWNLOAD_PRO2',function(){    
    DownloadCSV(2)
})

$(document).on('mouseenter','.ADDTOLIST_X',function()
{       
    $('.Span_Info' ).remove()
    var html="<div class='Span_Info'><span><p>Enter Data and Click to Append in List</p></span></div>"
    $('.SuperSpan0').append(html)
    setTimeout(function() { $('.Span_Info'). remove(); }, 5000); 
}
)
$(document).on('click','.ADDTOLIST_X',function(){    

    TEAM=$.cookie("TEAM") 
    var VERTICLENAME= $.cookie('SELECTEDVERTICLE')
    LAYER_VALUE=$('.INP0xDYN').val()
    if(LAYER_VALUE.length==0){
        $('.material-iconsD').remove()
        $('.infotextD').remove()
        $('.info').css('display','');     
        var html="<i class='material-iconsD' >"+ WARNING +"</i><p class='infotextC'>Empty Data Not Allowed</p>"
        $('.info').append(html);
        $('.info').css('background-color','rgb(238, 20, 20) ');
        $('.info').css('color','white');
        setTimeout(function() { $('.info'). hide(); }, 5000);     
        return false   
    }
    $.ajax
    ({
        url : '/api/ADDSINGLELAYER',
        data:{'xTEAM':TEAM,'xVALUEE':LAYER_VALUE,'xVERTICALNAME':VERTICLENAME},
        success:function(data)
        {             
            if(data['DETAILS']=='Data Added to list'){
                $('.material-iconsC').remove()
                $('.infotextC').remove()
	        $('.material-iconsx').remove()
        	$('.infotext').remove()
	        $('.material-iconsB').remove()
        	$('.infotextB').remove()
	        $('.material-iconsa').remove()
        	$('.infotexta').remove()
	        $('.material-iconsD').remove()
        	$('.infotextD').remove()
	        
                $('.info').css('display','');     
                var html="<i class='material-iconsC' >"+ ADDSUCS +"</i><p class='infotextC'>"+data['DETAILS']+"</p>"
                $('.info').append(html);
                $('.info').css('background-color','rgb(0, 255, 98)');
                setTimeout(function() { $('.info'). hide(); }, 5000);
            }else{
                $('.material-iconsC').remove()
                $('.infotextC').remove()
	        $('.material-iconsx').remove()
        	$('.infotext').remove()
	        $('.material-iconsB').remove()
        	$('.infotextB').remove()
	        $('.material-iconsa').remove()
        	$('.infotexta').remove()
                $('.material-iconsD').remove()
                $('.infotextD').remove()
                $('.info').css('display','');     
                var html="<i class='material-iconsD' >"+ ERRINDI +"</i><p class='infotextC'>"+data['DETAILS']+"</p>"
                $('.info').append(html);
                $('.info').css('background-color','rgb(238, 20, 20) ');
                $('.info').css('color','white');
                setTimeout(function() { $('.info'). hide(); }, 5000);
            }
        }})
})

$(document).on('change','.USERCODE',function()
{    
    SELECTION=$(this).val()
    $.cookie('MODE',SELECTION,{expires:2,path: '/'})
})


/*

*/