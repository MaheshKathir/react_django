from ast import Break, Del, If, Or, Pass, Try
from asyncio.windows_events import NULL
from ctypes.wintypes import INT
from fileinput import filename
from msilib.schema import Directory;from tkinter import EXCEPTION
from tkinter.tix import ROW, CheckList;from typing import Final
from unittest import result
from xml.dom.minidom import Element
from xml.etree.ElementTree import tostring
from flask import Flask , request , abort ,jsonify, redirect , Response ,url_for, render_template,session,g,send_file,make_response
from pandas.io.parquet import FastParquetImpl
from werkzeug.utils import secure_filename
from flask_login import LoginManager, UserMixin, \
                                login_required, login_user, logout_user 
from flask_login import LoginManager
import glob;import io
import xlwt;from flask_login import UserMixin
import json;from datetime import date, datetime,timedelta
import os;from openpyxl import load_workbook
from time import sleep;import string;import random
import pandas as pd ;import numpy as np;import pyodbc
from sqlalchemy import create_engine
import urllib;import re,json,time,easygui,openpyxl;
from getmac import get_mac_address as gma
import getmac
from fpdf import FPDF
from time import sleep
import shutil
from cryptography.fernet import Fernet


decrypted = b"!@#$%^&*()_-+=|\{[]}';:/?.>,<* 0123456789AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz"
#encrypted = b"QqWwEeRrTtYyUuIiOoPpAaSsDdFfGgHhJjKkLlZzXxCcVvBbNnMm!@#$%^&*()_-+=|\{[]}';:/?.>,<* 9876543210"
encrypted = b"QqWwEeRrTtYyUuIiOoPpAaSsDdFfGgHhJjKkLlZzXxCcVvBbNnMm!:/?.>,<* 98765@#$%^&*()_-+=|\{[]}';43210"

encrypt_table = bytes.maketrans(decrypted, encrypted)
decrypt_table = bytes.maketrans(encrypted, decrypted)

Directory=os.getcwd()
template_dir=os.path.join(Directory,'templates')
static_dir=os.path.join(Directory,'static')
JS_dir=os.path.join(static_dir,'JSFOLDER')
JSON_dir=os.path.join(static_dir,'JSONFOLDER')
MJSON_dir=os.path.join(JSON_dir,'USER_JSON')

#Program Developed By ManiBharathi
app = Flask(__name__,template_folder=template_dir,static_folder=static_dir)

UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

JSON_FOLDER = 'static/JSONSFOLDER/USER_JSON'
app.config['JSON_FOLDER'] = JSON_FOLDER

UPLOAD_MHA_FOLDER = 'static/Muploads'
app.config['UPLOAD_MHA_FOLDER'] = UPLOAD_MHA_FOLDER

ONEFINEDAY_FOLDER = 'static/_pycache_'
#ONEFINEDAY_FOLDER = 'static/uploads'
app.config['ONEFINEDAY_FOLDER'] = ONEFINEDAY_FOLDER

app.secret_key = os.urandom(12)
app.config.update(SECRET_KEY=app.secret_key,ENV='development')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['UPLOAD_MHA_FOLDER'] = UPLOAD_MHA_FOLDER
app.config['ONEFINEDAY_FOLDER'] = ONEFINEDAY_FOLDER



login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

global uploads_dir

#ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif','xlsx','xls'])
ALLOWED_EXTENSIONS = set(['xlsx'])

#for sqlite Db configuration
app.config['SQLALCHEMY_DATABASE_URI'] ='sqlite:///AA_Compliance_Team.db'
db = create_engine(app.config['SQLALCHEMY_DATABASE_URI'])

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def removePrevious(ProvidedPath):
    path = ProvidedPath
    for f in glob.iglob(path+'/**/*.xlsx', recursive=True):
        os.remove(f)

@app.route("/api/loginWEB", methods=['GET', 'POST'])
def LOGinWEB(USERid,xTEAMNAME):
    result=[]
#    USERid=request.args.get('xUSER')
#    xTEAMNAME=request.args.get('xTEAM')
    try:
        cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                            'Server=RegistryMgmt;'
                            'Database=A_TEAM;'
                            'UID=sa;'
                            'PWD=@dmin03*5;'
                            'Trusted_Connection=no;')   
        cnxn.autocommit = True                            
        cur = cnxn.cursor()
        
    except:
        return render_template('User.html',msg='connection error,try again !')     

    now = datetime.now()
    LOGIN_DATE=now.strftime("%Y-%m-%d")
    LogINtime = now.strftime("%H:%M:%S")
    

    
    DATA={'USERNAME':USERid},{'STATUS':'LOGGED_IN'},{'LOGGED_AT':str(LogINtime)},{'SELECTED_TEAM':xTEAMNAME}

    filename=MJSON_dir+'/'+USERid+'log.json'

#    print(os.stat(filename).st_size==0)
    try:
        if(os.stat(filename).st_size!=0):        
            REASUMEPROCESSX(USERid,xTEAMNAME)        
            return jsonify({
                            'DETAILS':'OK',
                            })  
        else:
            FindDATA=""" select * from MANIAPP_LOG WHERE Logged_in_DATE=? and Emp_id=? """
            WPRAMET=(LOGIN_DATE,USERid)            
            cur.execute(FindDATA,WPRAMET)                
            LISTcol=cur.fetchall()    
            if(len(LISTcol)==0):
                cur.execute("INSERT INTO MANIAPP_LOG(Emp_id,Logged_in_DATE,IN_TIME)values(?,?,?)",USERid,LOGIN_DATE,LogINtime)    
                cnxn.commit()   

            Fin={'logDetails':DATA},{'PROCESS':[]},{'NONPROCESS':[]},{'MID_0FF':[]}
            XDATA={"LAYER":Fin}
            with open(filename,'w') as F:
                    try:
                        data=json.load(F)
                    except:
                        json.dump(Fin,F,indent=4)
            return jsonify({
                                'DETAILS':'OK',
                                })
    except:
            FindDATA=""" select * from MANIAPP_LOG WHERE Logged_in_DATE=? and Emp_id=? """
            WPRAMET=(LOGIN_DATE,USERid)            
            cur.execute(FindDATA,WPRAMET)                
            LISTcol=cur.fetchall()    
            if(len(LISTcol)==0):
                cur.execute("INSERT INTO MANIAPP_LOG(Emp_id,Logged_in_DATE,IN_TIME)values(?,?,?)",USERid,LogINtime,LOGIN_DATE)    
                cnxn.commit()   

            Fin={'logDetails':DATA},{'PROCESS':[]},{'NONPROCESS':[]},{'MID_0FF':[]}
            XDATA={"LAYER":Fin}
            with open(filename,'w') as F:
                    try:
                        data=json.load(F)
                    except:
                        json.dump(Fin,F,indent=4)
            return jsonify({
                                'DETAILS':'OK',
                                })


def REASUMEPROCESSX(USERid,xTEAMNAME):
    timeList=[];N=5

#    USERid=request.args.get('xUSER')
    TYPE=request.args.get('TYPE')
    TIMExTAKEN=request.args.get('TIMETAKEN')

    filename=MJSON_dir+'/'+USERid+'log.json'
    now = datetime.now()
    STARTDATE = now.strftime("%Y-%m-%d")
    STARTtime = now.strftime("%H:%M:%S")
    DATA={'STARTDATE':STARTDATE},{'STARTED_AT':STARTtime}
    TYPE='PROCESS'

    with open(filename,'r+t',encoding = 'utf-8') as F:       
            data=json.load(F)    

            if(TYPE=='PROCESS'):
                res = ''.join(random.choices(string.ascii_uppercase + string.digits, k = N))
                sleep(.5)
                now=datetime.now().strftime("%m%d%S")                    
                print(now)                    
                Uniqu=now+res                

                return jsonify({
                                'DETAILS':'OK',
                                'UNIQNESS_IS_MAINTAINED':str(Uniqu)
                                })                           

    return jsonify({
                    'DETAILS':'OK',                    
                    })


@app.route("/api/STARTPROCESS", methods=['GET', 'POST'])
def STARTPROCESSX():
    timeList=[];N=5

    USERid=request.args.get('xUSER')
    TYPE=request.args.get('TYPE')
    TIMExTAKEN=request.args.get('TIMETAKEN')

    filename=MJSON_dir+'/'+USERid+'log.json'
    now = datetime.now()
    STARTDATE = now.strftime("%Y-%m-%d")
    STARTtime = now.strftime("%H:%M:%S")
    if(TYPE=='RESUME'):
        DATA={'STARTDATE':STARTDATE},{'STARTED_AT':TIMExTAKEN}
    else:
        DATA={'STARTDATE':STARTDATE},{'STARTED_AT':STARTtime}

    with open(filename,'r+t',encoding = 'utf-8') as F:        
            data=json.load(F)    
            if(TYPE=='PROCESS'):
                res = ''.join(random.choices(string.ascii_uppercase + string.digits, k = N))
                sleep(.5)
                now=datetime.now().strftime("%m%d%S")                    
                print(now)                    
                Uniqu=now+res                
                try:                       
                    with open(filename) as file:
                        data=json.load(file)
                        for x in data: 
                            if ('PROCESS' in x):x['PROCESS']=DATA
                except:
                    ret=data[1]['PROCESS'].append(DATA)        
                with open(filename,'w') as F:
                    json.dump(data,F,indent=4)
                return jsonify({
                                'DETAILS':'OK',
                                'UNIQNESS_IS_MAINTAINED':str(Uniqu)
                                })                    
            elif(TYPE=='NONPROCESS' or TYPE=='IDLE'):                
                try:                       
                    with open(filename) as file:
                        data=json.load(file)
                        for x in data: 
                            if ('NONPROCESS' in x):x['NONPROCESS']=DATA
                except:                                    
                    ret=data[2]['NONPROCESS'].append(DATA)                               
            elif(TYPE=='RESUME'):
                try:                       
                    with open(filename) as file:
                        data=json.load(file)
                        for x in data: 
                            if ('MID_0FF' in x):
                                try:
                                    if(x['MID_0FF'][1]['STARTED_AT']!=''):
                                        t1 =datetime.strptime(x['MID_0FF'][1]['STARTED_AT'], '%H:%M:%S')
                                        t2 = datetime.strptime(TIMExTAKEN, '%H:%M:%S')
                                        time_zero =datetime.strptime('00:00:00', '%H:%M:%S')
                                        ADDTIME=(t1 - time_zero + t2).time()
                                        DATA={'STARTDATE':STARTDATE},{'STARTED_AT':str(ADDTIME)}
                                        x['MID_0FF']=DATA
                                except:
                                    x['MID_0FF']=DATA                                                                                        
                except:                                                        
                    x['MID_0FF']=DATA                            
            #print(ret)
            #F.truncate(0)
            with open(filename,'w') as F:
                json.dump(data,F,indent=4)
    return jsonify({
                    'DETAILS':'OK',                    
                    })

@app.route("/api/STOPPROCESS", methods=['GET', 'POST'])
def STOPPROCESSX():
    cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                                            'Server=RegistryMgmt;'
                                            'Database=A_TEAM;'
                                            'UID=sa;'
                                            'PWD=@dmin03*5;'
                                            'Trusted_Connection=no;')
    cnxn.autocommit = True                                
    cur = cnxn.cursor()                                                

    USERid=request.args.get('xUSER');TEAM=request.args.get('xTEAM');TYPE=request.args.get('TYPE');
    UNIQX=request.args.get('UNIQ');UNITS=request.args.get('NOOFUNIT');MULTIPLY=request.args.get('MULTIPLX');
    TIMExTAKEN=request.args.get('ACTUALTIME'); SUTGIVEN=request.args.get('SUTTIME'); LAYER0=request.args.get('LAYER0')
    LAYER1=request.args.get('LAYER1'); LAYER2=request.args.get('LAYER2');   LAYER3=request.args.get('LAYER3')
    LAYER4=request.args.get('LAYER4'); LAYER5=request.args.get('LAYER5');   STARTTIME=request.args.get('START');STARTDATEX=request.args.get('SDATE')
    ENDTIME=datetime.now().strftime('%H:%M:%S');XREMARKX=request.args.get('REMARKS');YREMARK=request.args.get('REMARKX');TDATE=date.today()
    BREAKxINFO=request.args.get('BRINFO');BREAKxREMARK=request.args.get('BRREMARKS');IDELFOR=request.args.get('IDELREASON')
    xSTATUSx=request.args.get('JOBSTATUS');USERTYPE=request.args.get('TYPEOFUSER')
    now=datetime.now().strftime("%Y-%m-%d")
    filename=MJSON_dir+'/'+USERid+'log.json'

    if(TYPE=='ONLY_NONPROCESS'):
        TYPEX='NON PROCESS'
    elif(TYPE=='IDLE'):
        TYPEX='IDLE'        
    elif(TYPE=='RESUME'):
        TYPEX='NON PROCESS'
    else:
        TYPEX='PROCESS'
    if(TYPE=='ONLY_NONPROCESS'):
        cur.execute("INSERT INTO MANIMADE(TEAM_CODE,XUSER_ID,ACTIVITY,EST_SUT,START_TIME,END_TIME,TIMETAKEN,BREAK_INFO,BREAK_REMARK,EXTRA02,DATEDUPLICATE)values(?,?,?,?,?,?,?,?,?,?,?)", TEAM,USERid,TYPEX,SUTGIVEN,STARTTIME,ENDTIME,TIMExTAKEN,BREAKxINFO,BREAKxREMARK,TDATE,STARTDATEX)    
    elif(TYPE=='IDLE'):
        cur.execute("INSERT INTO MANIMADE(TEAM_CODE,XUSER_ID,ACTIVITY,EST_SUT,START_TIME,END_TIME,TIMETAKEN,BREAK_INFO,BREAK_REMARK,EXTRA02,DATEDUPLICATE)values(?,?,?,?,?,?,?,?,?,?,?)", TEAM,USERid,TYPEX,SUTGIVEN,STARTTIME,ENDTIME,TIMExTAKEN,'IDLE',IDELFOR,TDATE,STARTDATEX) 
    elif(TYPE=='RESUME'):        
        cur.execute("INSERT INTO MANIMADE(TEAM_CODE,XUSER_ID,ACTIVITY,SYS_ID,EST_SUT,START_TIME,END_TIME,TIMETAKEN,BREAK_INFO,BREAK_REMARK,EXTRA02,DATEDUPLICATE)values(?,?,?,?,?,?,?,?,?,?,?,?)", TEAM,USERid,TYPEX,UNIQX,SUTGIVEN,STARTTIME,ENDTIME,TIMExTAKEN,BREAKxINFO,BREAKxREMARK,TDATE,STARTDATEX)    
    else:
        cur.execute("INSERT INTO MANIMADE(TEAM_CODE,XUSER_ID,ACTIVITY,SYS_ID,MAIN_LYR,SUB_LYR,ACTIVITY_LYR_1,EST_SUT,START_TIME,END_TIME,TIMETAKEN,UNIT,SUTxUNIT,REMARK,EXTRA02,EXTRA01,DATEDUPLICATE,JOB_STATUS,TYPE_OF_USER)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", TEAM,USERid,TYPEX,UNIQX,LAYER0,LAYER1,LAYER2,SUTGIVEN,STARTTIME,ENDTIME,TIMExTAKEN,UNITS,MULTIPLY,XREMARKX,TDATE,YREMARK,STARTDATEX,xSTATUSx,USERTYPE)

    cnxn.commit()     
    FINDUSERID= """ DELETE Live_data  WHERE EMP_ID=? and xDate=?"""
    UPDATEPRAMET=(USERid,now)
    cur.execute(FINDUSERID,UPDATEPRAMET)
    cnxn.commit()            
    if(TYPEX=='PROCESS'):
        with open(filename,'r+t',encoding = 'utf-8') as F:   
                    try:
                        with open(filename) as file:
                            data=json.load(file)
                            for x in data: 
                                try:
                                    if(x['MID_0FF'][1]['STARTED_AT']!=''):
                                        DATA={'STARTED_AT':"00:00:00"}
                                        x['MID_0FF']=DATA
                                except:
                                    pass
                    except:                                                        
                        pass                   
        with open(filename,'w') as F:
            json.dump(data,F,indent=4)
            print('Cleared')

    return jsonify({

                            'STATUS':'DATA APPENDED SUCCESSFULLY',                                           
                                }) 

@app.route("/api/USERSgraph")
def USERSIDE_graph():
                    PREP_PRO_PROCESS=[];PRO_COUNT=[];PREP_NPRO_COUNT=[];PREP_O_HEADER=[]
                    TODY=date.today()
                    CURRENTUSERLOGGED = request.args.get('xUSER')   
                    XSTARTDATE = request.args.get('SDATE')   
                    XENDDATE = request.args.get('EDATE')   
                    cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                                                    'Server=RegistryMgmt;'
                                                    'Database=A_TEAM;'
                                                    'UID=sa;'
                                                    'PWD=@dmin03*5;'
                                                    'Trusted_Connection=no;')
                    cnxn.autocommit = True                                
                    cur = cnxn.cursor()  
                    QPREPCOUNT=""" SELECT * FROM USER_UTILIZ_TIMEDATA WHERE XUSER_ID=? and XDATE BETWEEN ? AND ?"""
                    SQLPREPCOUNT=(CURRENTUSERLOGGED,XSTARTDATE,XENDDATE)
                    cur.execute(QPREPCOUNT,SQLPREPCOUNT)
                    PREPPROCOUNT=cur.fetchall()
                    for row in PREPPROCOUNT:
                        PRO_COUNT.append((row[2],str(row[3])))                        
                            
                    return jsonify({          'PREPCHEADER':PREP_O_HEADER,
                                            'PRENPPROCOUNT':PREP_NPRO_COUNT,
                                            'PREPPROCOUNT':PRO_COUNT,
                                    })                                                      

@app.route("/api/ADMINgraph")
def ADMINSIDE_graph():
                    PREP_PRO_PROCESS=[];PRO_COUNT=[];PREP_NPRO_COUNT=[];PREP_O_HEADER=[];USER_ID=[]
                    TODY=date.today()
                    XTEAM = request.args.get('XTEAMX')   
                    XSTARTDATE = request.args.get('SDATE')   
                    XENDDATE = request.args.get('EDATE')   
                    cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                                                    'Server=RegistryMgmt;'
                                                    'Database=A_TEAM;'
                                                    'UID=sa;'
                                                    'PWD=@dmin03*5;'
                                                    'Trusted_Connection=no;')
                    cnxn.autocommit = True                                
                    cur = cnxn.cursor()  
                    QPREPCOUNT=""" SELECT * FROM ADMIN_LIST WHERE TEAM_CODE=? and XDATE BETWEEN ? AND ?"""
                    SQLPREPCOUNT=(XTEAM,XSTARTDATE,XENDDATE)
                    cur.execute(QPREPCOUNT,SQLPREPCOUNT)
                    PREPPROCOUNT=cur.fetchall()
                    for row in PREPPROCOUNT:
                        PRO_COUNT.append((row[2],str(row[4])))     
                        USER_ID.append((row[1]))
                            
                    return jsonify({          'PREPCHEADER':PREP_O_HEADER,
                                            'PRENPPROCOUNT':PREP_NPRO_COUNT,
                                            'PREPPROCOUNT':PRO_COUNT,
                                            'XIDS':USER_ID,
                                    })         

@app.route("/api/logoutWEB", methods=['GET', 'POST'])
def LOGoutWEB():
    USERid=request.args.get('xUSER')
    filename=MJSON_dir+'/'+USERid+'log.json'
    with open(filename) as file:
         data=json.load(file)
         for x in data:
            del x
    with open(filename,'w') as F:
         print('File Neutral')
    return jsonify({
                    'STATUS':'LOGGED OUT'
                   })
    

@app.route("/api/CREATExTEAM", methods=['GET', 'POST'])
def createTEAMJSON():
    Team=request.args.get('TEAMNAME')
    filename=JSON_dir+'/'+Team+'.json'
    with open(filename,'w')as F:
        try:
            data=json.load(F)
        except:
            pass
    return jsonify({
                    'TEAMNAME':Team,
                    })

@app.route("/api/CONFIGxTEAM", methods=['GET', 'POST'])
def ConfigTEAMJSON():
    result=[];Fin=[];LISTOFLAYERS=[]
    Team=request.args.get('TEAMNAME')
    colNo=request.args.get('NOoFcol')
    DATA={'Team':Team,'NOCol':str(colNo)}

    filename=JSON_dir+'/'+Team+'.json'

    Fin={'configure':DATA},{'LAYER':[{'LAYERx1':[]},{'LAYERx2':[]},{'LAYERx3':[]},{'LAYERx4':[]},{'LAYERx5':[]},{'LAYERx6':[]},{'LAYERx7':[]},{'LAYERx8':[]}]},{'SUTinfo':[]}
    XDATA={"LAYER":Fin}
    with open(filename,'w') as F:
        try:
            data=json.load(F)
        except:
            json.dump(Fin,F,indent=4)
    return jsonify({
                    'DETAILS':'OK',
                    })
@app.route("/api/SUTxTEAMDATA", methods=['GET', 'POST'])
def ADDINGSUTTOLAYER():
    result=[];Fin=[]
    Team=request.args.get('TEAMNAME')
    SUTVALUE=request.args.get('LAYERSUT')
    LAYERVALUE=request.args.get('LAYERDATA')    
    
    DATA={str(LAYERVALUE):str(SUTVALUE)}
    filename=JSON_dir+'/'+Team
    
    
    with open(filename,'r+t',encoding = 'utf-8') as F:
        
            data=json.load(F)
            print(data[2]['SUTinfo'])
            ret=data[2]['SUTinfo'].append(DATA)                               
            print(ret)
            F.truncate(0)
            with open(filename,'w') as F:
                json.dump(data,F,indent=4)
    return jsonify({
                    'DETAILS':'OK',
                    })

@app.route("/api/CONFIGxTEAMDATA", methods=['GET', 'POST'])
def configTEAMDATAJSON():
    result=[];Fin=[]
    SLOTNO=request.args.get('SLOT')
    LAYER=request.args.get('LAYER')
    LAYER_DETAIL=str('LAYER'+str(int(SLOTNO)+1))
    A_LAYER=str('LAYERx'+str(int(SLOTNO)+1))
    LAYERX=request.args.get('NAMELAYER')
    LAYERXM=request.args.get('MXL')
    print(int(SLOTNO))
    Team=request.args.get('TEAMNAME')
    if(int(SLOTNO)==2):
        DATA={LAYER_DETAIL:LAYER,'FIND':LAYERX,'FINDM':LAYERXM}
    else:
        DATA={LAYER_DETAIL:LAYER,'FIND':LAYERX}
    filename=JSON_dir+'/'+Team
    
    
    with open(filename,'r+t',encoding = 'utf-8') as F:
        
            data=json.load(F)
            print(data[1]['LAYER'][int(SLOTNO)])
            ret=data[1]['LAYER'][int(SLOTNO)][A_LAYER].append(DATA)                               
            print(ret)
            F.truncate(0)
            with open(filename,'w') as F:
                json.dump(data,F,indent=4)
            
    return jsonify({
                    'DETAILS':'OK',
                    })


@app.route("/api/DownlUserX", methods =["GET", "POST"])
def DownloadUxTable():
    #GIVEN_DATE=TODY=date.today()
    XSDATE=request.args.get('SDATE')
    XEDATE=request.args.get('EDATE')
    GIVEN_TEAM=request.args.get('XTEAMX')
    GIVEN_USER=request.args.get('XUSERX')
    REQ_FROM=request.args.get('USERMODE')
    FEATUREX=request.args.get('Feature')

    cnxn=pyodbc.connect(
                            'Driver={SQL Server Native Client 11.0};'
                            'Server=RegistryMgmt;'
                            'Database=A_TEAM;'
                            'UID=sa;'
                            'PWD=@dmin03*5;'
                            'Trusted_Connection=no;'
                        )   
    cur = cnxn.cursor()
#    cur.execute('Select * FROM View_12')
#    UQsql = """SELECT * FROM DOWNLOAD_TEMP WHERE XDATE BETWEEN ? AND ? AND TEAM_CODE=? AND XUSER_ID=? """
    if(REQ_FROM=='ADMIN'):
        UQsql = """SELECT * FROM DOWNLOAD_TEMP WHERE XDATE BETWEEN ? AND ? AND TEAM_CODE=? """
        UData=(XSDATE ,XEDATE,GIVEN_TEAM)    
        cur.execute(UQsql,UData)
    else:
        if(FEATUREX=='0'):
            UQsql = """SELECT * FROM DOWNLOAD_TEMP WHERE XDATE BETWEEN ? AND ? AND XUSER_ID=? AND ACTIVITY=?"""
            UData=(XSDATE ,XEDATE,GIVEN_USER,'PROCESS')    
            cur.execute(UQsql,UData)
        elif(FEATUREX=='1'):
            UQsql = """SELECT * FROM DOWNLOAD_TEMP WHERE XDATE BETWEEN ? AND ? AND XUSER_ID=? AND ACTIVITY=?"""
            UData=(XSDATE ,XEDATE,GIVEN_USER,'NON PROCESS')    
            cur.execute(UQsql,UData)
        elif(FEATUREX=='2'):
            UQsql = """SELECT * FROM DOWNLOAD_TEMP WHERE XDATE BETWEEN ? AND ? AND XUSER_ID=? AND ACTIVITY=?"""
            UData=(XSDATE ,XEDATE,GIVEN_USER,'IDLE')    
            cur.execute(UQsql,UData)            
    Xobj   =cur.fetchall()

    pdf = FPDF(orientation='L', unit='pt', format='A4')
    pdf.add_page()


    pdf.set_font("Times",'B', size=5)
   
    pdf.cell(35,10, str('START DATE'),border=1)
    pdf.cell(35,10, str('END DATE'),border=1)
    pdf.cell(60,10, str('TEAM NAME'),border=1)
    pdf.cell(30,10, str('EMP-ID'),border=1)
    pdf.cell(50,10, str('ACTIVITY'),border=1)
    pdf.cell(50,10, str('UNIQ ID'),border=1)
    pdf.cell(50,10, str('MAIN LAYER'),border=1)
    pdf.cell(50,10, str('SUB LAYER'),border=1)
    pdf.cell(50,10, str('ACTIVITY'),border=1)
    pdf.cell(60,10, str('BREAK'),border=1)
    pdf.cell(80,10, str('BREAK REMARK'),border=1)
    pdf.cell(80,10, str('REMARK'),border=1)
    pdf.cell(30,10, str('UNIT'),border=1)
    pdf.cell(30,10, str('SUT'),border=1)
    pdf.cell(30,10, str('SUT*UNIT'),border=1)
    pdf.cell(30,10, str('START TIME'),border=1)
    pdf.cell(30,10, str('END TIME'),border=1)
    pdf.cell(40,10, str('TIME TAKEN'),border=1)
    pdf.ln(10)
    pdf.set_font("Times", size=5)
    for row in Xobj:        
        pdf.cell(35,10, str(row.XDATE),border=1)
        pdf.cell(35,10, str(row.EXTRA02),border=1)
        pdf.cell(60,10, str(row.TEAM_CODE),border=1)
        pdf.cell(30,10, str(row.XUSER_ID),border=1)
        pdf.cell(50,10, str(row.ACTIVITY),border=1)
        pdf.cell(50,10, str(row.SYS_ID),border=1)
        pdf.cell(50,10, str(row.MAIN_LYR),border=1)
        pdf.cell(50,10, str(row.SUB_LYR),border=1)
        pdf.cell(50,10, str(row.ACTIVITY_LYR_1),border=1)
        pdf.cell(60,10, str(row.BREAK_INFO),border=1)
        pdf.cell(80,10, str(row.BREAK_REMARK),border=1)
        pdf.cell(80,10, str(row.REMARK),border=1)
        pdf.cell(30,10, str(row.UNIT),border=1)
        pdf.cell(30,10, str(row.EST_SUT),border=1)
        pdf.cell(30,10, str(row.SUTxUNIT),border=1)
        pdf.cell(30,10, str(row.START_TIME),border=1)
        pdf.cell(30,10, str(row.END_TIME),border=1)
        pdf.cell(40,10, str(row.TIMETAKEN),border=1)
        pdf.ln(10)

    pdf.ln(5)

    response = make_response(pdf.output(dest='S').encode('latin-1'))
    response.headers.set('Content-Disposition', 'attachment', filename=  'test.pdf')
    response.headers.set('Content-Type', 'application/pdf')
    return response           

@app.route("/api/AdminDOWNLOADTEAM", methods =["GET", "POST"])
def TEAMREPORT():
                TEAM=''
                XSDATE=request.args.get('SDATE')
                XEDATE=request.args.get('EDATE')
                GIVEN_TEAM=request.args.get('XTEAMX')
                GIVEN_USER=request.args.get('XUSERX')
                REQ_FROM=request.args.get('USERMODE')
                FEATUREX=request.args.get('Feature')
                cnxn=pyodbc.connect(
                                        'Driver={SQL Server Native Client 11.0};'
                                        'Server=RegistryMgmt;'
                                        'Database=A_TEAM;'
                                        'UID=sa;'
                                        'PWD=@dmin03*5;'
                                        'Trusted_Connection=no;'
                                    )   
                cur = cnxn.cursor()
                if(REQ_FROM=='ADMIN'):
                    UQsql = """SELECT * FROM DOWNLOAD_TEMP WHERE XDATE BETWEEN ? AND ? AND TEAM_CODE=? """
                    UData=(XSDATE ,XEDATE,GIVEN_TEAM)    
                    cur.execute(UQsql,UData)
                elif(REQ_FROM=='MIS'):
                    if(GIVEN_TEAM!='ALL'):
                        UQsql = """SELECT * FROM DOWNLOAD_TEMP WHERE XDATE BETWEEN ? AND ? AND Vertical=? """
                        UData=(XSDATE ,XEDATE,GIVEN_TEAM)    
                        cur.execute(UQsql,UData)                    
                    else:
                        UQsql = """SELECT * FROM DOWNLOAD_TEMP WHERE XDATE BETWEEN ? AND ? """
                        UData=(XSDATE ,XEDATE)    
                        cur.execute(UQsql,UData)                                      
                else:
                    if(FEATUREX=='0'):
                        UQsql = """SELECT * FROM DOWNLOAD_TEMP WHERE XDATE BETWEEN ? AND ? AND XUSER_ID=? AND ACTIVITY=?"""
                        UData=(XSDATE ,XEDATE,GIVEN_USER,'PROCESS')    
                        cur.execute(UQsql,UData)
                    elif(FEATUREX=='1'):
                        UQsql = """SELECT * FROM DOWNLOAD_TEMP WHERE XDATE BETWEEN ? AND ? AND XUSER_ID=? AND ACTIVITY=?"""
                        UData=(XSDATE ,XEDATE,GIVEN_USER,'NON PROCESS')    
                        cur.execute(UQsql,UData)
                    elif(FEATUREX=='2'):
                        UQsql = """SELECT * FROM DOWNLOAD_TEMP WHERE XDATE BETWEEN ? AND ? AND XUSER_ID=? AND ACTIVITY=?"""
                        UData=(XSDATE ,XEDATE,GIVEN_USER,'IDLE')    
                        cur.execute(UQsql,UData)  
                Xobj   =cur.fetchall()

                output = io.BytesIO()
                workbook = xlwt.Workbook()
                sh = workbook.add_sheet('Summary Report')
                #add headers
                
                sh.write(0, 0, 'START DATE')
                sh.write(0, 1, 'END DATE')
                sh.write(0, 2, 'TEAM')
                sh.write(0, 3, 'EMP ID')
                sh.write(0, 4, 'NAME OF EMPLOYEE')                
                sh.write(0, 5, 'ACTIVITY')
                sh.write(0, 6, 'UNIQ ID')
                sh.write(0, 7, 'LAYER 1(MAIN LAYER)')
                sh.write(0, 8, 'LAYER 2(SUB LAYER)')
                sh.write(0, 9, 'LAYER 3(ACTIVITY)')
                sh.write(0, 10, 'BREAK INFO')
                sh.write(0, 11, 'BREAK REMARK')
                sh.write(0, 12, 'PROCESS REMARK')
                sh.write(0, 13, 'REASON FOR EXCEEDING SUT/ABNORMAL EXIT')
                sh.write(0, 14, 'UNIT')
                sh.write(0, 15, 'EST_SUT')
                sh.write(0, 16, 'SUT * UNIT')
                sh.write(0, 17, 'START TIME')
                sh.write(0, 18, 'END TIME')
                sh.write(0, 19, 'TIME TAKEN')
                sh.write(0, 20, 'USER TYPE')
                sh.write(0, 21, 'JOB STATUS')
                sh.write(0, 22, 'FINAL STATUS')                


                idx = 1
                for row in Xobj:   
                                                             
                    sh.write(idx+1, 0, str(row.XDATE))
                    sh.write(idx+1, 1, row.EXTRA02)
                    sh.write(idx+1, 2, row.TEAM_CODE)
                    sh.write(idx+1, 3, row.XUSER_ID)
                    sh.write(idx+1, 4, row.Employee_name)                    
                    sh.write(idx+1, 5, row.ACTIVITY)
                    sh.write(idx+1, 6, row.SYS_ID)
                    sh.write(idx+1, 7, row.MAIN_LYR)
                    sh.write(idx+1, 8, row.SUB_LYR)
                    sh.write(idx+1, 9, row.ACTIVITY_LYR_1)
                    sh.write(idx+1, 10, row.BREAK_INFO)
                    sh.write(idx+1, 11, row.BREAK_REMARK)
                    sh.write(idx+1, 12, row.EXTRA01)
                    sh.write(idx+1, 13, row.REMARK)                     
                    sh.write(idx+1, 14, str(row.UNIT))
                    sh.write(idx+1, 15, str(row.EST_SUT))
                    sh.write(idx+1, 16, str(row.SUTxUNIT))
                    sh.write(idx+1, 17, str(row.START_TIME))
                    sh.write(idx+1, 18, str(row.END_TIME))
                    sh.write(idx+1, 19, str(row.TIMETAKEN))
                    sh.write(idx+1, 20, row.TYPE_OF_USER)
                    sh.write(idx+1, 21, row.JOB_STATUS)
                    sh.write(idx+1, 22, row.FINAL_STATUS)                    
                    idx += 1
                   
                workbook.save(output)
                output.seek(0)    

                return Response(output, mimetype="application/ms-excel", headers={"Content-Disposition":"attachment;filename=employee_Daily_report.xls"})                    

@app.route("/api/loginoutDOWNLOAD",methods=["GET","POST"])
def loginout():

                XSDATE=request.args.get('SDATE')
                XEDATE=request.args.get('EDATE')

                cnxn=pyodbc.connect(
                                        'Driver={SQL Server Native Client 11.0};'
                                        'Server=RegistryMgmt;'
                                        'Database=A_TEAM;'
                                        'UID=sa;'
                                        'PWD=@dmin03*5;'
                                        'Trusted_Connection=no;'
                                    )   
                cur = cnxn.cursor()
                UQsql = """SELECT * FROM OVERALL_MANICREATED_LOGIOUT_REPORT WHERE LOG_IN_DATE BETWEEN ? AND ? """
                UData=(XSDATE ,XEDATE)    
                cur.execute(UQsql,UData)  
                Xobj   =cur.fetchall()

                output = io.BytesIO()
                workbook = xlwt.Workbook()
                sh = workbook.add_sheet('Summary Report')
                #add headers
                
                sh.write(0, 0, 'Employee id')
                sh.write(0, 1, 'Employee Name')
                sh.write(0, 2, 'Vertical name')
                sh.write(0, 3, 'Log in Date')
                sh.write(0, 4, 'Log in Time')                
                sh.write(0, 5, 'Log Out Date')
                sh.write(0, 6, 'Log Out Time')
                idx = 1
                for row in Xobj:   
                                                             
                    sh.write(idx+1, 0, row.EMP_ID)
                    sh.write(idx+1, 1, row.EMP_NAME)
                    sh.write(idx+1, 2, row.Vertical)
                    sh.write(idx+1, 3, str(row.LOG_IN_DATE))
                    sh.write(idx+1, 4, str(row.LOG_IN))
                    sh.write(idx+1, 5, str(row.LOG_OUT_DATE))
                    sh.write(idx+1, 6, str(row.LOG_OUT))
                    idx += 1
                   
                workbook.save(output)
                output.seek(0)    

                return Response(output, mimetype="application/ms-excel", headers={"Content-Disposition":"attachment;filename=LogInOut_report.xls"})                    
#****   ****#
@app.route("/api/GETUSERLIST", methods =["GET", "POST"])
def AdminUserList():
    GIVEN_TEAM=request.args.get('XTEAMX')
    GIVEN_USER=request.args.get('XUSERX')
    USERLIST=[];TOTAL_HRS=[]

    cnxn=pyodbc.connect(
                            'Driver={SQL Server Native Client 11.0};'
                            'Server=RegistryMgmt;'
                            'Database=A_TEAM;'
                            'UID=sa;'
                            'PWD=@dmin03*5;'
                            'Trusted_Connection=no;'
                        )   
    cur = cnxn.cursor()
    UQsql = """SELECT * FROM TEAMWISE_USERLIST WHERE TEAM_CODE=? """

    UData=(GIVEN_TEAM)    
    cur.execute(UQsql,UData)
    Xobj   =cur.fetchall()
    for row in Xobj:    
            USERLIST.append(str(row.XUSER_ID))
            TOTAL_HRS.append(str(row.TIMETAKENX))
    return jsonify({
                    'xUSERLISTx':USERLIST,
                    'xHOURSx':TOTAL_HRS
                    })    

@app.route("/api/GETUSERLIVEDATA", methods =["GET", "POST"])
def exposeLIVE():
    TEAMxNAME=request.args.get('XTEAMX')
    
    now=datetime.now().strftime("%Y-%m-%d")
    DATE_X=[]
    TEAMNAME=[]
    EMPIDX=[]
    ACTIVITYX=[]
    ACTIVNAMEX=[]
    STARTTIMEX=[]
    EMPLOYEENAME=[]

    cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                                            'Server=RegistryMgmt;'
                                            'Database=A_TEAM;'
                                            'UID=sa;'
                                            'PWD=@dmin03*5;'
                                            'Trusted_Connection=no;')
    cnxn.autocommit = True                                
    cur = cnxn.cursor()      
    
    FindDATA=""" select * from User_livedata_withName WHERE xDate=? and Team=? """
    WPRAMET=(now,TEAMxNAME)
    
    cur.execute(FindDATA,WPRAMET)
        
    LISTcol=cur.fetchall()
    print(LISTcol)
    for row in LISTcol:
        DATE_X.append(str(row[0]))
        TEAMNAME.append(str(row[1]))
        EMPIDX.append(str(row[2]))
        EMPLOYEENAME.append(str(row[3]))
        ACTIVITYX.append(str(row[4]))
        ACTIVNAMEX.append(str(row[5]))
        STARTTIMEX.append(str(row[6]))
        

    return jsonify({
            'LIVE_DATE':DATE_X,
            'LIVE_TEAM':TEAMNAME,
            'LIVE_EMPID':EMPIDX,
            'LIVE_EMPNAME':EMPLOYEENAME,
            'LIVE_ACTIVITY':ACTIVITYX,
            'LIVE_ACTNAME':ACTIVNAMEX,
            'LIVE_STARTTIME':STARTTIMEX,
                })     

@app.route("/api/LIVExDATA", methods =["GET", "POST"])
def UserLIVE():
    
    GIVEN_USER=request.args.get('xUSER')
    GIVEN_ACTIVITY=request.args.get('DATAACTIVE')
    ACTIVITY_TYPE=request.args.get('TYPE')
    TEAMNAME=request.args.get('XTEAMX')
    TDATE=date.today()
    now=datetime.now().strftime("%Y-%m-%d")
    StartTime=datetime.now().strftime("%H:%M:%S")
    USERLIST=[];TOTAL_HRS=[]

    cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                                            'Server=RegistryMgmt;'
                                            'Database=A_TEAM;'
                                            'UID=sa;'
                                            'PWD=@dmin03*5;'
                                            'Trusted_Connection=no;')
    cnxn.autocommit = True                                
    cur = cnxn.cursor()      
    
    FindDATA=""" select * from Live_data WHERE EMP_ID=? and xDate=?"""
    WPRAMET=(GIVEN_USER,now)
    cur.execute(FindDATA,WPRAMET)
    LISTcol=cur.fetchall()
    print(len(LISTcol))
    if(len(LISTcol)==0):
        cur.execute("INSERT INTO Live_data(Emp_ID,Team,Activity,Activity_Name,StartTime)values(?,?,?,?,?)",GIVEN_USER,TEAMNAME,ACTIVITY_TYPE,GIVEN_ACTIVITY,StartTime)
        cnxn.commit()    
    else:
        FINDUSERID= """ UPDATE Live_data SET Activity=?,Team=?,Activity_Name=?,StartTime=? WHERE EMP_ID=? and xDate=?"""
        UPDATEPRAMET=(ACTIVITY_TYPE,TEAMNAME,GIVEN_ACTIVITY,StartTime,GIVEN_USER,now)
        cur.execute(FINDUSERID,UPDATEPRAMET)
        cnxn.commit()            
    return jsonify({
                    'DETAILS':'OK',
                    })
         
@app.route('/upload', methods=['POST'])
def upload_file():
    
    # check if the post request has the file part
    if 'files[]' not in request.files:
        resp = jsonify({'message' : 'No file part in the request'})
        resp.status_code = 400
        return resp
     
    files = request.files.getlist('files[]')
     
    errors = {}
    success = False

    removePrevious(UPLOAD_FOLDER)

    for file in files:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename).split('/')[-1].split('.')[0]
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename+'.xlsx'))
            success = True
        else:
            errors[file.filename] = 'File type is not allowed'
    if success and errors:
        errors['message'] = 'File(s) successfully uploaded'
        resp = jsonify(errors)
        resp.status_code = 206
        STATUS="GOOD TO GO"
    return jsonify({
                    'DETAILS':'OK',
                    })        

@app.route('/uploadM', methods=['POST'])
def Mupload_file():
    
    # check if the post request has the file part
    if 'files[]' not in request.files:
        resp = jsonify({'message' : 'No file part in the request'})
        resp.status_code = 400
        return resp
     
    files = request.files.getlist('files[]')
     
    errors = {}
    success = False

#    removePrevious(UPLOAD_FOLDER)
    
    for file in files:
            filename = secure_filename(file.filename).split('/')[-1].split('.')[0]
            file.save(os.path.join(app.config['UPLOAD_MHA_FOLDER'], filename+'.txt'))
            success = True
    if success and errors:
        errors['message'] = 'File(s) successfully uploaded'
        resp = jsonify(errors)
        resp.status_code = 206
        STATUS="GOOD TO GO"
    return jsonify({
                    'DETAILS':'OK',
                    })


@app.route("/api/READXLSX", methods =["GET", "POST"])
def READMYXLSFILE():    
    upTEAMNAME=request.args.get('TEAMNAME')
    ACTUALMHAEXCELPATH=UPLOAD_FOLDER
    filenames = glob.glob(ACTUALMHAEXCELPATH + "/*.xlsx")   


    result=[];Fin=[];LISTOFLAYERS=[]
    Team=request.args.get('TEAMNAME')
    colNo=4
    DATA={'Team':upTEAMNAME,'NOCol':str(colNo)}
    source = JSON_dir+'/'+Team+'.json'
    target = JSON_dir+'/'+Team+'0310.json'

    shutil.copy(source, target)        
    filename=JSON_dir+'/'+Team+'0310.json'
    if os.path.exists(filename):
        print ('Yaa it exists!')
        readANDcreateJSON(filenames,filename)
    else:        
        Fin={'configure':DATA},{'LAYER':[{'LAYERx1':[]},{'LAYERx2':[]},{'LAYERx3':[]},{'LAYERx4':[]},{'LAYERx5':[]},{'LAYERx6':[]},{'LAYERx7':[]},{'LAYERx8':[]}]},{'SUTinfo':[]}
        XDATA={"LAYER":Fin} 
        with open(filename,'w') as F:
            try:
                data=json.load(F)
            except:
                json.dump(Fin,F,indent=4)
        sleep(3)
        readANDcreateJSON(filenames,filename)
    old_filename= JSON_dir+'/'+Team+'.json'
    for f in glob.iglob(old_filename):
        os.remove(f)   

    os.rename(filename, filename.replace('0310', ''))
    return jsonify({
                                    'DETAILS':'UPLOAD SUCCESS',
                                    })       

@app.route("/api/SHOW_WORKFLOW", methods =["GET", "POST"])
def DISPLAY_WORKFLOW():
    TEAM_NAME=[];VERT_NAME=[];ENTITY=[];JOB_STAT=[]
    TEAM=request.args.get('XTEAMX')
    cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                                            'Server=RegistryMgmt;'
                                            'Database=A_TEAM;'
                                            'UID=sa;'
                                            'PWD=@dmin03*5;'
                                            'Trusted_Connection=no;')
    cnxn.autocommit = True                                
    cur = cnxn.cursor()      

    FindDATA=""" select * from WorkFlow WHERE TEAM_CODE=? """
    VERPRAMET=(TEAM)    
    cur.execute(FindDATA,VERPRAMET)            
    Vertic_RESULTS=cur.fetchall()  
    print(Vertic_RESULTS)
    if(bool(Vertic_RESULTS)):
            for row in Vertic_RESULTS:
                TEAM_NAME.append(str(row[0]))
                VERT_NAME.append(str(row[1]))
                ENTITY.append(str(row[2]))
                JOB_STAT.append(str(row[3]))

    return jsonify({
            'TEAMNAME':TEAM_NAME,
            'VERTICAL':VERT_NAME,
            'N_ENTITY':ENTITY,
            'X_STATUS':JOB_STAT
                })    

@app.route("/api/DELETE_WORKFLOW_FRMLIST", methods =["GET", "POST"])
def DELETE_WORKFLOW():
    X_VERTICAL=request.args.get('VERTICAL')
    X_TEAMNAME=request.args.get('TEAMNAME')
    X_ENITYNAME=request.args.get('ENITYNAME')
    source = JSON_dir+'/'+X_TEAMNAME+'.json'

    cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                                            'Server=RegistryMgmt;'
                                            'Database=A_TEAM;'
                                            'UID=sa;'
                                            'PWD=@dmin03*5;'
                                            'Trusted_Connection=no;')
    cnxn.autocommit = True                                
    cur = cnxn.cursor()      

    FindDATA=""" UPDATE MANIMADE SET FINAL_STATUS=? WHERE TEAM_CODE=? and MAIN_LYR=? and ACTIVITY=?"""
    PARAMETR=('COMPLETED',X_TEAMNAME,X_ENITYNAME,'PROCESS')
    cur.execute(FindDATA,PARAMETR)        
    try:
            with open(source ,'r+t',encoding = 'utf-8') as F:
                data=json.load(F)
                LAYER1=data[1]['LAYER'][0]['LAYERx1']
                for l,val in enumerate(LAYER1):
                    print(val) 
                    if(X_ENITYNAME in val['FIND'] and 'MANIBHARATHI' in val['LAYER1']):
                        print(val)
                        LAYER1.pop(l)
                        with open(source,'w') as F:
                                json.dump(data,F,indent=4)                       
            return jsonify({
                            'ONGOING_PROCESS':'DONE',
                            })     
    except:
         return jsonify({
                        'ONGOING_PROCESS':'Unable to complete Task Try again later',    
                        })

@app.route("/set")
def setcookie():
    USERid=request.args.get('xUSER')
    filename=MJSON_dir+'/'+USERid+'log.json'
    now = datetime.now()
    STARTDATE = now.strftime("%Y-%m-%d")
    STARTtime = now.strftime("%H:%M:%S")
    DATA={'STARTDATE':STARTDATE},{'STARTED_AT':STARTtime}

    now=datetime.now().strftime("%Y-%m-%d")
    DATE_X=[];    TEAMNAME=[];    EMPIDX=[];    ACTIVITYX=[];    ACTIVNAMEX=[];    STARTTIMEX=[]

    cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                                            'Server=RegistryMgmt;'
                                            'Database=A_TEAM;'
                                            'UID=sa;'
                                            'PWD=@dmin03*5;'
                                            'Trusted_Connection=no;')
    cnxn.autocommit = True                                
    cur = cnxn.cursor()      

    FindDATA=""" select * from Live_data WHERE Emp_ID=? and xDate=? """

    WPRAMET=(USERid,now)
    
    cur.execute(FindDATA,WPRAMET)
            
    COUNTRESULTS=cur.fetchall()        
    print(COUNTRESULTS)     
    if(bool(COUNTRESULTS)):
        for row in COUNTRESULTS:
            DATE_X.append(str(row[1]))
            TEAMNAME.append(str(row[2]))
            EMPIDX.append(str(row[3]))
            ACTIVITYX.append(str(row[4]))
            ACTIVNAMEX.append(str(row[5]))
            STARTTIMEX.append(str(row[6]))
            out = jsonify(state=0, msg='success')
            out.set_cookie('STATUS', str(row[4]),expires='1')
            out.set_cookie('PREV_SELECTED_TEAM', str(row[2]),expires='1')
            return out
#        return jsonify({
#                        'ONGOING_PROCESS':ACTIVITYX,
#                        })
    else:
        try:
            with open(filename) as file:
                        data=json.load(file)
                        for x in data: 
                            if('logDetails' in x):
                                PREV_TEAM=x['logDetails'][3]['SELECTED_TEAM']
                            if ('NONPROCESS' in x):x['NONPROCESS']=DATA
            with open(filename,'w') as F:
                json.dump(data,F,indent=4)
                                            
            out = jsonify(state=0, msg='success')
            out.set_cookie('STATUS', 'IDLE',expires='1')        
            out.set_cookie('PREV_SELECTED_TEAM',PREV_TEAM,expires='1')
            out.set_cookie('TEAM',PREV_TEAM,expires='1')
            return out
        except:
            out = jsonify(state=0, msg='New Data')
            return out

@app.route("/api/ADDSINGLELAYER", methods =["GET", "POST"])    
def SingleData():
                SingleField=request.args.get('xVALUEE')
                Team=request.args.get('xTEAM')
                Vertical=request.args.get('xVERTICALNAME')
                filename=JSON_dir+'/'+Team+'.json'
                try:
                    if(Vertical=='AA_COMPLIANCE'):
                                                LAYER=SingleField;LAYERXM='MANIBHARATHI'
                                                ZA_LAYER=str('LAYERx'+str(int(0)+1))
                                                ZDATA={'LAYER1':LAYERXM,'FIND':LAYER}
                                                with open(filename,'r+t',encoding = 'utf-8') as F:            
                                                    data=json.load(F)                            
                                                    ret=data[1]['LAYER'][0][ZA_LAYER].append(ZDATA)  
                                                    F.truncate(0)
                                                    with open(filename,'w') as F:
                                                        json.dump(data,F,indent=4)
                                                old_filename= JSON_dir+'/'+Team+'.json'
                                                """
                                                for f in glob.iglob(old_filename):
                                                    os.remove(f)   

                                                os.rename(filename, filename.replace('0310', ''))
                                                """
                                                return jsonify({
                                                                                'DETAILS':'Data Added to list',
                                                                                })                                                               
                except:
                                                return jsonify({
                                                            'DETAILS':'Unable to access database,Try Again later ',
                                                            })    


def readANDcreateJSON(filenames,filename):
            for file in filenames:
                GET_FullView=pd.read_excel(file)
                GET_FILE=pd.read_excel(file)
                i=0
                for index,row in GET_FILE.iterrows():  
                    print(GET_FILE.columns)
                    SLOTNO=i
                    
                    LAYER_DETAIL=str('LAYER'+str(int(SLOTNO)+1))
                    A_LAYER=str('LAYERx'+str(int(SLOTNO)+1))
                    
                    print(int(SLOTNO))
                    Team=request.args.get('TEAMNAME')
                    Vertical=request.args.get('VERTICALNAME')
                    if(Vertical=='AA_COMPLIANCE'):
                        LAYER=row[0];LAYERXM='MANIBHARATHI'
                        ZA_LAYER=str('LAYERx'+str(int(0)+1))
                        ZDATA={'LAYER1':LAYERXM,'FIND':LAYER}
                        with open(filename,'r+t',encoding = 'utf-8') as F:            
                            data=json.load(F)                            
                            ret=data[1]['LAYER'][0][ZA_LAYER].append(ZDATA)  
                            F.truncate(0)
                            with open(filename,'w') as F:
                                json.dump(data,F,indent=4)
                    elif(Vertical=='Default'):
                        LAYER=row[0];LAYERX=row[1];LAYERY=row[2];LAYERXM='MANIBHARATHI'
                        SUTxM=str(row[3])
                        if(int(SLOTNO)==2):
                            DATA={LAYER_DETAIL:LAYERY,'FIND':LAYERX,'FINDM':LAYERXM}
                            yDATA={'LAYER2':LAYERX,'FIND':LAYERXM}
                            xDATA={'LAYER1':LAYERXM,'FIND':LAYER}
                            MDATA={LAYERY:SUTxM}
                        elif(int(SLOTNO)==1):
                            DATA={LAYER_DETAIL:LAYERX,'FIND':LAYERXM}
                            xDATA={'LAYER1':LAYERXM,'FIND':LAYER} 
                            yDATA={'LAYER3':LAYERY,'FIND':LAYERX,'FINDM':LAYERXM}       
                            MDATA={LAYERY:SUTxM}
                        elif(int(SLOTNO)==0):
                            DATA={LAYER_DETAIL:LAYERXM,'FIND':LAYER}
                            xDATA={'LAYER2':LAYERX,'FIND':LAYERXM}                      
                            yDATA={'LAYER3':LAYERY,'FIND':LAYERX,'FINDM':LAYERXM}        
                            MDATA={LAYERY:SUTxM}                   
                        with open(filename,'r+t',encoding = 'utf-8') as F:            
                            data=json.load(F)    
                            if(int(SLOTNO)==2):                
                                ret=data[1]['LAYER'][int(i)][A_LAYER].append(DATA)
                                ret=data[1]['LAYER'][int(i-1)]["LAYERx2"].append(yDATA)
                                ret=data[1]['LAYER'][int(i-2)]["LAYERx1"].append(xDATA)
                                ret=data[2]['SUTinfo'].append(MDATA)
                            elif(int(SLOTNO)==1):
                                ret=data[1]['LAYER'][int(i)][A_LAYER].append(DATA)
                                ret=data[1]['LAYER'][int(i-1)]["LAYERx1"].append(xDATA)
                                ret=data[1]['LAYER'][int(i+1)]["LAYERx3"].append(yDATA)
                                ret=data[2]['SUTinfo'].append(MDATA)
                            elif(int(SLOTNO)==0):
                                ret=data[1]['LAYER'][int(i)][A_LAYER].append(DATA)  
                                ret=data[1]['LAYER'][int(i+1)]["LAYERx2"].append(xDATA)
                                ret=data[1]['LAYER'][int(i+2)]["LAYERx3"].append(yDATA)
                                ret=data[2]['SUTinfo'].append(MDATA)
                            F.truncate(0)
                            with open(filename,'w') as F:
                                json.dump(data,F,indent=4)                                 
                    else:
                        LAYER=row[0];LAYERX=row[1];LAYERY=row[2];LAYERXM='MANIBHARATHI'
                        SUTxM=str(row[3])
                        if(int(SLOTNO)==2):
                            DATA={LAYER_DETAIL:LAYERY,'FIND':LAYERX,'FINDM':LAYER}
                            yDATA={'LAYER2':LAYERX,'FIND':LAYER}
                            xDATA={'LAYER1':LAYER,'FIND':'null'}
                            MDATA={LAYERY:SUTxM}
                        elif(int(SLOTNO)==1):
                            DATA={LAYER_DETAIL:LAYERX,'FIND':LAYER}
                            xDATA={'LAYER1':LAYER,'FIND':'null'} 
                            yDATA={'LAYER3':LAYERY,'FIND':LAYERX,'FINDM':LAYER}       
                            MDATA={LAYERY:SUTxM}
                        elif(int(SLOTNO)==0):
                            DATA={LAYER_DETAIL:LAYER,'FIND':'null'}
                            xDATA={'LAYER2':LAYERX,'FIND':LAYER}                      
                            yDATA={'LAYER3':LAYERY,'FIND':LAYERX,'FINDM':LAYER}        
                            MDATA={LAYERY:SUTxM}
                        print(index)
                        print(row[0])
                                        
                        with open(filename,'r+t',encoding = 'utf-8') as F:            
                            data=json.load(F)    
                            if(int(SLOTNO)==2):                
                                ret=data[1]['LAYER'][int(i)][A_LAYER].append(DATA)
                                ret=data[1]['LAYER'][int(i-1)]["LAYERx2"].append(yDATA)
                                ret=data[1]['LAYER'][int(i-2)]["LAYERx1"].append(xDATA)
                                ret=data[2]['SUTinfo'].append(MDATA)
                            elif(int(SLOTNO)==1):
                                ret=data[1]['LAYER'][int(i)][A_LAYER].append(DATA)
                                ret=data[1]['LAYER'][int(i-1)]["LAYERx1"].append(xDATA)
                                ret=data[1]['LAYER'][int(i+1)]["LAYERx3"].append(yDATA)
                                ret=data[2]['SUTinfo'].append(MDATA)
                            elif(int(SLOTNO)==0):
                                ret=data[1]['LAYER'][int(i)][A_LAYER].append(DATA)  
                                ret=data[1]['LAYER'][int(i+1)]["LAYERx2"].append(xDATA)
                                ret=data[1]['LAYER'][int(i+2)]["LAYERx3"].append(yDATA)
                                ret=data[2]['SUTinfo'].append(MDATA)                                
                            F.truncate(0)
                            with open(filename,'w') as F:
                                json.dump(data,F,indent=4)
                    i=i+1
                    if(i==3):
                        i=0

@app.route("/api/EDITSUT", methods =["GET", "POST"])
def EditJSON():
    TEAM=request.args.get('TEAMNAME')
    source = JSON_dir+'/'+TEAM+'.json'
    LAYER1=request.args.get('p_1')
    ACTIVITY=request.args.get('p_2')
    PREVIOUS_SUT=request.args.get('p_3')
    CURRENT_SUT=request.args.get('p_4')
    CONCATE=str(ACTIVITY+PREVIOUS_SUT)
    Format={ACTIVITY:CURRENT_SUT}
    TO_FIND="".join(ch for ch in str(CONCATE) if ch.isalnum())
    try:
            with open(source ,'r+t',encoding = 'utf-8') as F:
                    data=json.load(F)
                    SUT=data[2]['SUTinfo'] 
                    for key,value in enumerate(SUT): 
                        cleanString = "".join(ch for ch in str(value) if ch.isalnum())
                        if(cleanString==TO_FIND):
                            data[2]['SUTinfo'].append(Format) 
                            SUT.pop(key)
                            with open(source,'w') as F:
                                json.dump(data,F,indent=4)      
            return jsonify({
                            'ONGOING_PROCESS':'Update Success',
                            })                                                      

    except:
            return jsonify({
                            'ONGOING_PROCESS':'Unable to complete Task Try again later',
                            })                                   

@app.route("/api/DELETESUT", methods =["GET", "POST"])
def DELJSON():
    TEAM=request.args.get('TEAMNAME')
    source = JSON_dir+'/'+TEAM+'.json'
    LAYER1=request.args.get('p_1')
    ACTIVITY=request.args.get('p_2')
    PREVIOUS_SUT=request.args.get('p_3')
    CURRENT_SUT=request.args.get('p_4')
    CONCATE=str(ACTIVITY+PREVIOUS_SUT)
    Format={ACTIVITY:CURRENT_SUT}
    TO_FIND="".join(ch for ch in str(CONCATE) if ch.isalnum())
    try:
            with open(source ,'r+t',encoding = 'utf-8') as F:
                    data=json.load(F)
                    SUT=data[2]['SUTinfo'] 
                    SECOND_LAYER=data[1]['LAYER'][2]['LAYERx3']
                    print(SECOND_LAYER)
                    for key,value in enumerate(SUT): 
                        cleanString = "".join(ch for ch in str(value) if ch.isalnum())
                        if(cleanString==TO_FIND):
                            SUT.pop(key)
                    for k,val in enumerate(SECOND_LAYER): 
                            print(val['LAYER3'])
                            if(ACTIVITY in val['LAYER3'] and LAYER1 in val['FINDM']):
                                print(val)
                                SECOND_LAYER.pop(k)
                                with open(source,'w') as F:
                                     json.dump(data,F,indent=4)        
            return jsonify({
                            'ONGOING_PROCESS':'Following ACTIVITY'+ACTIVITY+' is Deleted From List',
                            })                                                                                    

    except:
            return jsonify({
                            'ONGOING_PROCESS':'Unable to complete Task Try again later',
                            })                                   

@app.route("/api/RemoveJSON",methods=["GET", "POST"]  )
def REMOVEJSONS():
    TEAM=request.args.get('TEAMNAME')
    source = JSON_dir+'/'+TEAM+'.json'
    print(TEAM)
    try:
            os.remove(source)
            return jsonify({
                            'ONGOING_PROCESS':'Following Team is Removed',
                            })                                                       
    except:
            return jsonify({
                            'ONGOING_PROCESS':'Unable to complete Task Try again later',
                            })        

@app.route("/", methods=['GET', 'POST'])
@login_required
def home(name=None):       
    """ Session control"""
    if not session.get('logged_in'):
        return render_template('index.html')
    else:
        if request.method == 'POST':
            #username = getname(request.form['username'])
            return render_template('index.html')
        return render_template('index.html')


class User(UserMixin):
    cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                            'Server=RegistryMgmt;'
                            'Database=ACCOUNT_AND_FINANCE_USERDB;'
                            'UID=sa;'
                            'PWD=@dmin03*5;'
                            'Trusted_Connection=no;')   
    cnxn.autocommit = True                            
    cur = cnxn.cursor()
    ALUsql = """SELECT * FROM USERLOG_A_F"""
    cur.execute(ALUsql)
    users=cur.fetchall()

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login Form"""
    global name
    session.permanent = True
    cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                            'Server=RegistryMgmt;'
                            'Database=A_TEAM;'
                            'UID=sa;' 
                            'PWD=@dmin03*5;'
                            'Trusted_Connection=no;')   
    cnxn.autocommit = True                            
    cur = cnxn.cursor() 
    
    if request.method == 'GET':
        return render_template('User.html')
    else:
        name = request.form['username'].upper()
        passw = request.form['password']
        
        message = passw
        result = message.translate(encrypt_table)

        mode=request.form['TYPEOFUSERS']
        FORMNAME=request.form['FORMNAME']
        UQsql = """SELECT * FROM REGISTER_MANIAPP WHERE Employee_id =? AND Password=?"""
        UData=(name,result)
        try:
            cur.execute(UQsql,UData)
            row_count = cur.rowcount
            if row_count != 0:                
                session[name] = name
                LOGinWEB(name,FORMNAME)
                UniquX=''
                XN = 5
                RXN = ''.join(random.choices(string.ascii_uppercase + string.digits, k = XN))
                now=datetime.now().strftime("%m%d%S")              
                UniquX=now+RXN

                #login_user(name)
                set_session(name,mode,UniquX)
                if(name!='' and mode!='' ):
                    return redirect(url_for('set_session', user_name=name,user_mode=mode,user_Uxinx=UniquX))
                else:
                    return render_template('404Errorpage.html')

#                return render_template('OneVueUI.html/<string:user_name>')
            else:
                UQsql = """SELECT * FROM REGISTER_MANIAPP WHERE Employee_id =?"""
                UData=(name)
                cur.execute(UQsql,UData)                                
                row_count = cur.rowcount
                if row_count != 0:                       
                    return render_template('User.html',msg='Invalid Password !',murl='/Forgot!')                    
                else:
                    return render_template('User.html',msg='Kindly register as New User')
        except:
            return render_template('User.html',msg='USER ID NOT FOUND !')
#            return redirect(url_for('set_session', user_name=name,user_mode=mode))


@login_manager.user_loader
def load_user(userid):
    return User(userid)


#Program Developed By ManiBharathi
#Process Start
@app.route('/Logged-in/<user_name>/<user_mode>/<user_Uxinx>/',methods=['GET'],strict_slashes=False)
@login_manager.user_loader
def set_session(user_name,user_mode,user_Uxinx):
    session["user_name"] = user_name
    session["user_mode"] = user_mode
    session["user_Uxinx"] = user_Uxinx
    
    print(user_mode)
    if(user_mode=='Employee'):
        print('User')        
        return render_template('User.html')
    elif(user_mode=='MIS' and user_name=='S99023'):
        print('Create')
        return render_template('Create.html')
    elif(user_mode=='Manager'):
        print('SPECIALIST_APP')
        return render_template('Admin.html')
    elif(user_mode=='INDEXING_APP'):
        print('INDEXING_APP')
        return render_template('FUND_INDEXING.html')    
    elif(user_mode=='REPORTING_APP'):        
        print('FUND_REPORTING')
        return render_template('FUND_REPORTING.html')
    elif(user_mode=='ADMIN'):
        print('ADMIN')
        return render_template('ADMIN.html')         
    else:
        print('PROCESSOR')
        return render_template('User.html')

@app.route('/ERROR/', methods=['GET', 'POST'])
def GotoError()    :
    return render_template('404Errorpage.html')



@app.route('/register/', methods=['GET', 'POST'])
def register():
    """Register Form"""
    cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                            'Server=RegistryMgmt;'
                            'Database=A_TEAM;'
                            'UID=sa;'
                            'PWD=@dmin03*5;'
                            'Trusted_Connection=no;')   
    cnxn.autocommit = True                            
    cur = cnxn.cursor()    


    if request.method == 'POST':
        username=request.form['username']
        password=request.form['password']
        empxName=request.form['xEMPNAME']        
        vertName=request.form['Verticle']

        message = password
        encryp_pass = message.translate(encrypt_table)

        if (username=='' or empxName ==''or password=='' or vertName==''):
            return render_template('register.html',msg='Null_Values_Not_Allowed')
        UQsql = """SELECT * FROM REGISTER_MANIAPP WHERE Employee_id =?"""
        UData=(username)

        cur.execute(UQsql,UData)
        row_count = cur.rowcount
        if row_count == 0:
            cur.execute("insert into REGISTER_MANIAPP (Employee_id,Password,Employee_name,Ip_address,Verticle) values (?,?,?,?,?)",username ,encryp_pass,empxName,str(request.environ['REMOTE_ADDR']),vertName)
            cnxn.commit()
            return render_template('register.html')
        else:
            return render_template('register.html',msg='Duplication_Not_Allowed')
                    
    return render_template('register.html')           


@app.route('/Forgot!/', methods=['GET', 'POST'])
def Fword():        
    cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                            'Server=RegistryMgmt;'
                            'Database=A_TEAM;'
                            'UID=sa;'
                            'PWD=@dmin03*5;'
                            'Trusted_Connection=no;')   
    cnxn.autocommit = True                            
    cur = cnxn.cursor()    

    if request.method == 'POST':
        username=request.form['username']
        password=request.form['RESETpassword']

        message = password
        encryp_pass = message.translate(encrypt_table)        

        FINDUSERID= """ UPDATE REGISTER_MANIAPP SET PASSWORD=? WHERE Employee_id=?"""
        RESETPRAM=(encryp_pass,username)
                
        cur.execute(FINDUSERID,RESETPRAM)                    
        cnxn.commit()
        return render_template('User.html')    
    return render_template('PASSWORD_RESET.html')           


@app.route("/api/logoutX")
def LOUT():
    USERid=request.args.get('xUSER')
    TIMExTAKEN=request.args.get('TOTALTIME')

    try:
        cnxn=pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                            'Server=RegistryMgmt;'
                            'Database=A_TEAM;'
                            'UID=sa;'
                            'PWD=@dmin03*5;'
                            'Trusted_Connection=no;')   
        cnxn.autocommit = True                            
        cur = cnxn.cursor()
        
    except:
        return render_template('User.html')     

    now = datetime.now()
    TODY=now.strftime("%Y-%m-%d")    
    LogOutTime = now.strftime("%H:%M:%S")    
    print(LogOutTime)

    
    FINDLOG = """SELECT * FROM MANIAPP_LOG WHERE Emp_id =? AND Logged_in_DATE=?"""
    LOGPRAM=(USERid,TODY)
                
    cur.execute(FINDLOG,LOGPRAM)
    row_count = cur.rowcount
    if row_count != 0:             
                Xobj   =cur.fetchall()
                for row in Xobj:
                    TimeAdd=row[6]      
                    print(TimeAdd)  
                try:
                    t1 =datetime.strptime(TimeAdd, '%H:%M:%S')
                    t2 = datetime.strptime(TIMExTAKEN, '%H:%M:%S')
                    time_zero =datetime.strptime('00:00:00', '%H:%M:%S')
                    ADDTIME=(t1 - time_zero + t2).time()                    
                except:
                    ADDTIME=TIMExTAKEN
                FINDLOG= """ UPDATE MANIAPP_LOG SET  Logged_out_DATE=? ,OUT_TIME=?,Time_Spent=? WHERE EMP_ID=? and Logged_in_DATE=?"""
                LOGPRAM=(TODY,LogOutTime,str(ADDTIME),USERid,TODY)
                cur.execute(FINDLOG,LOGPRAM)
                cnxn.commit()        
    return render_template('index.html')
#    return jsonify({        
#                            "msg":'SUCCESSFULLY LOGED-OUT FROM SESSION..!'
#                    })
    



@app.route("/api/logout")
@app.route("/logout")
@login_required
def logout():
    """Logout Form"""
    print('Logging Out...')
    session['logged_in'] = False
    return redirect(url_for('login'))

#Below code for AA_Compliance Purpose 08/05/2023

#For download the only excel format from AA_compliance create Page
@app.route('/download_excel_format_for_AA_compliance')
def download_excel_format_for_AA_compliance():
    data ={'Client Name':[], 'Job Name':[], 'SUT':[], 'Complision %':[]}
    df = pd.DataFrame(data)
    out_put = io.BytesIO()
    writer = pd.ExcelWriter(out_put, engine='xlsxwriter')
    df.to_excel(writer, index=False)
    writer.close()
    out_put.seek(0)
    response = make_response(out_put.getvalue())
    response.headers['Content-Disposition'] = 'attachment;filename=download_excel_format.xlsx'
    response.mimetype = 'application/vnd.ms-excel'
    return response

#For upload the AA_compliance excel file and store into the database
@app.route('/uplaod_AA_Compliance_Team', methods=['GET', 'POST'])
def uplaod_AA_Compliance_Team():
 
    file = request.files['uplaod_AA_Compliance_Team']
    # file.save(file.filename)
    data = pd.read_excel(file)
    data.to_sql('AA_Compliance_Team', db, if_exists="append", index=False)

    # return data.to_html()
    
    return jsonify({'status':'success'})

#For download the AA_compliance excel file from the mis team page
@app.route('/download_AA_Compliance_MIS', methods=['GET', 'POST'])
def download_AA_Compliance_MIS():
    data = pd.read_sql('SELECT * FROM AA_Compliance_Team', db)
    out_put = io.BytesIO()
    writer = pd.ExcelWriter(out_put, engine='xlsxwriter')
    data.to_excel(writer, index=False)
    writer.close()
    out_put.seek(0)
    response = make_response(out_put.getvalue())
    response.headers['Content-Disposition'] = 'attachment;filename=AA_Compliance_Team_data.xlsx'
    response.mimetype = 'application/vnd.ms-excel'
    return response

#End code for AA_Compliance Purpose 08/03/2023   

    
if __name__ == "__main__":
    app.run(debug=True,threaded = True)    
